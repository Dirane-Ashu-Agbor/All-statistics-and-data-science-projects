
# LOAD DATASET
DataSet<- read.table(file="C:/Users/diran/Downloads/Retake - Statistical Analysis of Reliability & Survival Data/DataSet.txt")
# Rename the variables in the dataset
library(tidyverse)
mydata<-DataSet
df<-mydata%>%rename(
  group = V1,
  timetodeath = V2,
  diseasefreetime = V3,
  death_ind = V4,
  relapse_ind = V5,
  deseasefree_surv_ind = V6,
  timetoAGVH = V7,
  AGVH_ind = V8,
  timeto_chronicGVHD = V9,
  chronicGVHD_ind = V10,
  timetoreturn_platelets = V11,
  plateletrecovery_ind = V12,
  p_age = V13,
  d_age = V14,
  p_sex = V15,
  d_sex = V16,
  p_CMVstatus = V17,
  d_CMVstatus = V18,
  waitingtime_transplant = V19,
  FAB_ind = V20,
  hospi_ind = V21,
  MTXused_ind = V22
)

str(df)

# Required packages.
library(survival)
library(survMisc)
library(dplyr)
library("car")
library("survminer")
library(SurvRegCensCov)
library(asaur)

# Question 1 (i)

surv1 <- Surv(df$diseasefreetime,df$relapse_ind)

surv1fit <- survfit(surv1~1, conf.type = "log")
options(max.print=10000) # Making R show all rows from the results.
summary(surv1fit) # Basic and raw display of the Survival Values.

# par(mfrow=c(1,1)) Just leaving here in case I need!
plot(surv1fit, xlab="Time (days)",ylab="Survival",
     main="Time to Relapse (log CI's)") # Basic Plot of S(t), as well as a=5% intervals.

ggsurvplot(surv1fit,data=df, title="Time to Relapse (log CI's')")

# To find the time when 25% of people are expected to have relapse,
# we find the quantile
quantile(surv1fit, probs=0.25, conf.int = TRUE) # Quantile for 25% of individuals with Relapse

# To find the survival probability after 1000 days with 95% C.I (log transformation)
summary(surv1fit, times = 1000) # Finding survival value for a 1000 days period.

# Is this value significantly different from 60%?

# Is this a proper confidence interval?

# Question 1 (ii)

#compare time until relapse in the 3 disease groups graphically and numerically

# Label group factor levels
df$group = factor(df$group)
table(df$relapse_ind, df$group) # Basic display of counts to give an overall feeling.

levels(df$group) = c("ALL","lowrisk","highrisk")
table(df$relapse_ind, df$group) # Basic display of counts to give an overall feeling.

surv2fit <- survfit(surv1~df$group, conf.type = "log") # This 2nd fit used the same surv1 info, but now instead of a intercept only model, it used the information of the group variable as predictor.
summary(surv2fit)
plot(surv2fit, col=c("red","blue","yellow"), xlab="Time (days)",ylab="Survival", main="Time to Relapse (by Disease Group) ")
legend("topright",legend=c("ALL","AML Low Risk","AML High Risk"), col=c("red", "blue", "yellow"), lty=1, cex = 0.8)

# Attempt at making the plot look better...
ggsurvplot(surv2fit, data=df,
           pval = TRUE, conf.int = TRUE,
           risk.table = FALSE, # Add risk table
           risk.table.col = "strata", # Change risk table color by groups
           linetype = "strata", # Change line type by groups
           surv.median.line = "hv", # Specify median survival
           ggtheme = theme_bw(), # Change ggplot2 theme
           palette = c("#E7B807","#E7B799","#2E9FDF"))

# numerical comparison of the different disease groups
options(digits=10) # Just making R show more decimals.
survdiff(surv1~df$group) # Log-rank
survdiff(surv1~df$group, rho = 1) # Peto & Peto weights

# Is there a trend in the survival functions of the 3 groups? Manual programming
OB<-survdiff(surv1~df$group)$obs
OB

EX<-survdiff(surv1~df$group)$exp
EX

V<-survdiff(surv1~df$group)$var
V

a<-c(1,2,3)
test<-a%*%(OB-EX)
stderror<-sqrt(t(a)%*%V%*%a)
zscore<-test/stderror
pvalue<-2*pnorm(abs(zscore),lower.tail = FALSE)
data.frame(test,stderror,zscore,pvalue)

# separate graph of 3 survival functions for male and female patients

# Label gender factor levels
df$p_sex = factor(df$p_sex)
table(df$relapse_ind, df$p_sex) # Basic display of counts to give an overall feeling.

levels(df$p_sex) = c("F","M")
table(df$relapse_ind, df$p_sex) # Basic display of counts to give an overall feeling.

# Part 01:

#Male:
fit_M <- survfit(Surv(diseasefreetime,relapse_ind) ~ group,data = df[which(df$p_sex=="M"),])
#Female:
fit_F <- survfit(Surv(diseasefreetime,relapse_ind) ~ group,data = df[which(df$p_sex=="F"),])

#Tests:
survdiff(Surv(diseasefreetime,relapse_ind) ~ group,data = df[which(df$p_sex=="M"),])
survdiff(Surv(diseasefreetime,relapse_ind) ~ group,data = df[which(df$p_sex=="F"),])

#Plots:
par(mfrow=c(1,2))
plot(y=fit_M[1]$surv,x=fit_M[1]$time,xlab="Time",ylab="Survival", pch = 1, lty = 1, type = "o", main = "Gender = Male", ylim = c(0,1))
lines(fit_M[2]$surv,x=fit_M[2]$time, pch = 2, lty = 2, type = "o",col="red")
lines(fit_M[3]$surv,x=fit_M[3]$time, pch = 3, lty = 3, type = "o",col="yellow")
legend("topright",c("ALL", "AML Low Risk", "AML High Risk"), pch = c(1,2,3), lty = c(1,2,3), col = c("black","red","yellow"))

plot(y=fit_F[1]$surv,x=fit_F[1]$time,xlab="Time",ylab="Survival", pch = 1, lty = 1, type = "o", main = "Gender = Female", ylim = c(0,1))
lines(fit_F[2]$surv,x=fit_F[2]$time, pch = 2, lty = 2, type = "o",col="red")
lines(fit_F[3]$surv,x=fit_F[3]$time, pch = 3, lty = 3, type = "o",col="yellow")
legend("topright",c("ALL", "AML Low Risk", "AML High Risk"), pch = c(1,2,3), lty = c(1,2,3), col = c("black","red","yellow"))

par(mfrow=c(1,1))

# Part 02:
# Bringing all together:
# Plotting may help us:
plot(y=fit_F[1]$surv,x=fit_F[1]$time,xlab="Time",ylab="Survival", pch = 1, lty = 1,type = "o", col="red", main = "Gender x Disease group", ylim = c(0,1))
lines(fit_F[2]$surv,x=fit_F[2]$time, pch = 2, lty = 2, type = "o",col="red")
lines(fit_F[3]$surv,x=fit_F[3]$time, pch = 3, lty = 3, type = "o",col="red")

lines(fit_M[1]$surv,x=fit_M[1]$time, pch = 1, lty = 1, type = "o",col="blue")
lines(fit_M[2]$surv,x=fit_M[2]$time, pch = 2, lty = 2, type = "o",col="blue")
lines(fit_M[3]$surv,x=fit_M[3]$time, pch = 3, lty = 3, type = "o",col="blue")

legend("topright",c("Female - ALL", "Female - AML Low Risk", "Female - AML High Risk", "Male - ALL", "Male - AML Low Risk", "Male - AML High Risk"), pch = c(1,2,3,1,2,3), lty = c(2,2,2,2,2,2), col = c("red","red","red","blue","blue","blue"))

# is gender a confounder?
survdiff(Surv(diseasefreetime,relapse_ind) ~ group + strata(p_sex),data = df)


#-----------QUESTION 2---------------


# question 2 (i)

# is there a significant effect of a patients age on time until relapse, as per cox model?
cox1 <- coxph(Surv(diseasefreetime,relapse_ind) ~ p_age, data = df)
cox1 # Simple look at model fit;
summary(cox1) # More complete look at model fit.

# question 2 (ii)
# interpretations of 2(i) above and verify proportional hazard assumption

#Schoenfeld residuals, as well as graphical analysis.
test.ph <- cox.zph(cox1)
test.ph
par(mfrow=c(1,1))
plot(test.ph)
ggcoxzph(test.ph)
par(mfrow=c(1,1))
mart1 = ggcoxdiagnostics(cox1, type = "martingale",
                         ox.scale = "observation.id", ggtheme = theme_light())
mart2 = ggcoxdiagnostics(cox1, type = "martingale",
                         ox.scale = "linear.predictions", ggtheme = theme_light())
require(gridExtra)
grid.arrange(mart1, mart2, ncol=2)

# Martingale residuals will be plotted against covariates for functional form check.
fitresi<-residuals(cox1,type="martingale")
par(mfrow=c(1,1))
plot(df$p_age,fitresi,xlab="Patient Age",ylab="Residuals")
lines(lowess(df$p_age,fitresi), col="red")


# Question 2 (iii)

# Dealing with ties using "exact method", do our results from 2(i) change?
cox3 <- coxph(Surv(diseasefreetime,relapse_ind) ~ p_age, data = df, method = "exact")
summary(cox3) # More complete look at model fit.

cox3b <- coxph(Surv(diseasefreetime,relapse_ind) ~ p_age, data = df, method = "breslow")
summary(cox3b) # More complete look at model fit.
# No changes when compared to 2(i)

# Question 2 (iv)
# impact of different methods of ties handling on the influence of group on survival time until relapse

# first check for ties
table(df$diseasefreetime,df$relapse_ind,df$group)

cox4a <- coxph(Surv(diseasefreetime,relapse_ind) ~ group,data = df)
summary(cox4a)
cox4b <- coxph(Surv(diseasefreetime,relapse_ind) ~ group,data = df, method = "breslow")
summary(cox4b)
cox4c <- coxph(Surv(diseasefreetime,relapse_ind) ~ group,data = df, method = "exact")
summary(cox4c)

# Question 2 (v)

# Setting the tone for the time-dependent AGVH_ind, chronicGVHD_ind and plateletrecovery_ind
# first create an ID column in the original data set if it is absent
df<-df %>% 
  mutate(ID = rownames(.)) %>% 
  select(ID, everything())

step1 = tmerge(data1=df, data2=df, id=ID,
               relapse=event(diseasefreetime,relapse_ind))
step2 = tmerge(data1=step1, data2=df, id=ID,
               acute=tdc(timetoAGVH))
step3 = tmerge(data1=step2, data2=df, id=ID,
               chronic=tdc(timeto_chronicGVHD))
step4 = tmerge(data1=step3, data2=df, id=ID,
               platelets=tdc(timetoreturn_platelets))

# model built with three time dependent covariates as requested.

cox5a1 = coxph(Surv(tstart, tstop, relapse) ~ acute, data=step4)
cox5a2 = coxph(Surv(tstart, tstop, relapse) ~ acute + chronic, data=step4)
cox5a3 = coxph(Surv(tstart, tstop, relapse) ~ acute + chronic + platelets, data=step4)


# interaction model
cox5b = coxph(Surv(tstart, tstop, relapse) ~ acute + chronic + platelets
              + acute:chronic + acute:platelets + chronic:platelets, data=step4)

# Summary info. on all models, 
summary(cox5a1)
summary(cox5a2)
summary(cox5a3)

summary(cox5b)

#Information criteria for both models.
AIC(cox5a3, cox5b)
BIC(cox5a3, cox5b)


#-------------------QUESTION 3---------------------------------#

# Question 3(i)

fit_i = survreg(Surv(diseasefreetime,relapse_ind) ~ p_age + p_sex + p_CMVstatus, data=df)
summary(fit_i)

fit_ii <- WeibullReg(Surv(diseasefreetime,relapse_ind) ~ p_age + p_sex + p_CMVstatus, data=df)
summary(fit_ii)
fit_ii

#Assessing the Weibull distribution for the baseline:
resKM <- survfit(Surv(diseasefreetime,relapse_ind) ~ 1, conf.type="none",data = df) # Basic model, I will check the weibull assump. on data, not specifically on a model with covariates etc.
survEst <- resKM$surv # In the next lines we extract times and survival estimates, transform them, and plot, looking for a straight line.
survTime <- resKM$time
logLogSurvEst <- log(-log(survEst))
logSurvTime <- log(survTime)
plot(logLogSurvEst ~ logSurvTime, ylab="log(-log(Survival)",col="red",main="Goodness-of-fit")
result.lm <- lm(logLogSurvEst ~ logSurvTime)
abline(result.lm)

# Looking into residuals now.
fitresi<-residuals(fit_i,type="deviance")
fitpred<-predict(fit_i)
#plot(fitresi,ylab="residuals")
par(mfrow=c(2,3))
plot(seq(1:137),fitresi,ylab="residuals", xlab="index",xlim = c(1,137))
lines(lowess(seq(1:137),fitresi))
plot(fitpred,fitresi,xlab="prediction",ylab="residuals")
lines(lowess(fitpred,fitresi))
plot(df$diseasefreetime,fitresi,xlab="TimeSurv",ylab="residuals")
lines(lowess(df$diseasefreetime,fitresi))
plot(df$p_age,fitresi,xlab="Patient Age",ylab="residuals")
lines(lowess(df$p_age,fitresi))
boxplot(df$p_sex,fitresi,xlab="Patient Sex",ylab="residuals",ylim=c(-3,3))
boxplot(df$p_CMVstatus,fitresi,xlab="Patient CMV status",ylab="residuals",ylim=c(-3,3))
par(mfrow=c(1,1))

# Question 3 (ii)
# how significance of covariates change when other distributions are considered. Which distribution is best?

fit_i <- survreg(Surv(diseasefreetime,relapse_ind) ~ p_age + p_sex + p_CMVstatus, data=df)
summary(fit_i)

fit_exp <- survreg(Surv(diseasefreetime,relapse_ind) ~ p_age + p_sex + p_CMVstatus, dist = "exponential", data=df)
summary(fit_exp)

fit_logn <- survreg(Surv(diseasefreetime,relapse_ind) ~ p_age + p_sex + p_CMVstatus, dist = "lognormal", data=df)
summary(fit_logn)

fit_loglog <- survreg(Surv(diseasefreetime,relapse_ind) ~ p_age + p_sex + p_CMVstatus, dist = "loglogistic", data=df)
summary(fit_loglog)

# AIC values for comparison
extractAIC(fit_i)
extractAIC(fit_exp)
extractAIC(fit_logn) # lowest AIC
extractAIC(fit_loglog)



