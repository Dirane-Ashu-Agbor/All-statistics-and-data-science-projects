
#########  QUESTION A #########

DataQA = read.table("covidDATA.txt")
modulo11=function(x) {x- floor(x/11)*11}
studentnumber=637968 # fill in your student number here, this is an example!
mycol=modulo11(studentnumber)
mydataA=DataQA[,c((1+mycol*4):(4+mycol*4))]

##  change date to days by creating a new column containing numbers from 1 to nth row
mydataA$days <- seq.int(nrow(mydataA))

# rename NEW_IN.1 column using dplyr package
library(dplyr)
mydataA <- mydataA %>% rename(covidcases=NEW_IN.1)

# take the log of new covid cases column
mydataA$covidcases <- round(log(mydataA$covidcases + 1),3)

head(mydataA,5)

# rename data object
df=mydataA

# density plot of the dependent variable log covidcases
plot(density(df$covidcases), main="", xlab="Log of Covid Hospital Intake", ylim=c(0,0.6),lwd = 2)

# Plot of data with a regression line
library(ggplot2)
ggplot(data = df,
       aes(x = days,
           y = covidcases))+
  geom_point(size = 1.2,
             alpha = .8,
             position = "jitter")+# to add some random noise for plotting purposes
  geom_smooth(method = lm,
              se     = FALSE, 
              col    = "black",
              size   = .5, 
              alpha  = .8)+ # to add regression line
  theme_minimal()+
  labs(title = "Covid Hospital Intakes vs. No.Days", subtitle = "add regression line")

# Creating column objects from the dataset
days=df[,5]
covidcases=df[,4]
province=df[,2]

plot.default(days,covidcases)

# Overfitted smoothing spline estimator
library(SemiPar)
fit2 = smooth.spline(days,covidcases)
fit2
lines(fit2,col="black",lwd = 1) # plot looks overfitted
#AIC
log.likelihood=fit2$fit$logLik
total.df=sum(fit2$aux$df)
-2*(log.likelihood-total.df)

# 1 linear spline model using mmaximum likelihood
fit3 = spm(covidcases ~ f(days, basis = "trunc.poly"), spar.method="ML") # degree=1 is default
summary(fit3)
lines(fit3,se=FALSE,col="blue",lwd = 2)
#AIC
log.likelihood=fit3$fit$logLik
total.df=sum(fit3$aux$df)
-2*(log.likelihood-total.df)

# 2 quadratic spline model using maximum likelihood
fit4 = spm(covidcases ~ f(days, basis = "trunc.poly", degree = 2), spar.method="REML")
summary(fit4)
lines(fit4,se=FALSE,col="red",lwd = 2)
#AIC
log.likelihood=fit4$fit$logLik
total.df=sum(fit4$aux$df)
-2*(log.likelihood-total.df)

# 3 cubic spline model using restricted maximum likelihood
fit5 = spm(covidcases ~ f(days, basis = "trunc.poly", degree = 3), spar.method="ML")
summary(fit5)
lines(fit5,se=FALSE,col="green",lwd = 2)
#AIC
log.likelihood=fit5$fit$logLik
total.df=sum(fit5$aux$df)
-2*(log.likelihood-total.df)

legend("topright", c("Overfitted","Linear", "Quadratic", "Cubic"), lty=1, col = c("black","blue","red","green"))

#  ALTERNATIVE
# GAM  using the GCV criterion for selecting smoothing parameter
#library(mgcv)
#fit6=gam(covidcases~s(days,bs="cr"),family = gaussian(), data=df) # GCV criterion is default
#summary(fit6)
#plot(fit6,se=TRUE)
#lines(fit6,se=FALSE,col="yellow",lwd = 2)



# A.2

# plotting 99% pointwise confidence intervals of each model on separate graphs
#----first extract std errors using predict function

# linear spline model
newdata<-data.frame(province,days,covidcases)
preds<-predict(fit3, newdata=newdata, se=TRUE)
print(preds)
# calculate and plot upper (U) and lower (L) 99% prediction intervals
U <- preds$fit + (2.58*preds$se)
L <- preds$fit - (2.58*preds$se)
plot(fit3,xlim=c(1,60),shade.col="cyan",ylab="log of hospital intake", main="99% conf interval for linear spline model")
points(unlist(newdata$days),preds$fit,col="red")
points(unlist(newdata$days),U,col="blue")
points(unlist(newdata$days),L,col="green")

# Quadratic spline model
newdata<-data.frame(province,days,covidcases)
preds4<-predict(fit4, newdata=newdata, se=TRUE)
print(preds4)
# calculate and plot upper (U) and lower (L) 99% prediction intervals
U <- preds4$fit + (2.58*preds4$se)
L <- preds4$fit - (2.58*preds4$se)
plot(fit4,xlim=c(1,60),shade.col="cyan",ylab="log of hospital intake", main="99% conf interval quadratic spline model")
points(unlist(newdata$days),preds4$fit,col="red")
points(unlist(newdata$days),U,col="blue")
points(unlist(newdata$days),L,col="green")

# polynomial spline model
newdata<-data.frame(province,days,covidcases)
preds5<-predict(fit5, newdata=newdata, se=TRUE)
print(preds5)
# calculate and plot upper (U) and lower (L) 99% prediction intervals
U <- preds5$fit + (2.58*preds5$se)
L <- preds5$fit - (2.58*preds5$se)
plot(fit5,xlim=c(1,60),shade.col="cyan",ylab="log of hospital intake", main="99% conf interval for polynomial spline model")
points(unlist(newdata$days),preds5$fit,col="red")
points(unlist(newdata$days),U,col="blue")
points(unlist(newdata$days),L,col="green")

# A.3
#---- see pdf file 



#########  QUESTION B

DataQB = read.table("BankDefaultData.txt",header=T)
studentnumber = 637968 # fill in your student number here, this is an example!
set.seed(studentnumber)
rownumbers = sample(1:6436,size=1000)
mydataB = DataQB[rownumbers,]

## The above generates the dataset for Question B
# lets first look at the summary of dataset
summary(mydataB)
# identify missing values
sum(is.na(mydataB))

#load library
library(dplyr)
library(ggplot2)
library(GGally)
library(MASS)
library(glmnet)

mydataB$Education = as.character(mydataB$Education)
mydataB$Education = factor(mydataB$Education, levels = c("N","P","M","S","H"))
mydataB$Gender = as.character(mydataB$Gender)
mydataB$Gender = factor(mydataB$Gender, levels = c("M","F"))
mydataB$Phone = as.character(mydataB$Phone)
mydataB$Phone = factor(mydataB$Phone, levels = c("Y","N"))
mydataB$Customer = as.character(mydataB$Customer)
mydataB$Customer = factor(mydataB$Customer, levels = c("N","E"))
head(mydataB)

# As observed there are four variables Gender,Education,Phone and Customer which are having levels or factors. 
#So for analysis they need to converted into numeric variables. Applying the transformation.

#mydataB$Gender= as.numeric(as.factor(mydataB$Gender))
#mydataB$Education= as.numeric(as.factor(mydataB$Education))
#mydataB$Phone= as.numeric(as.factor(mydataB$Phone))
#mydataB$Customer= as.numeric(as.factor(mydataB$Customer))

# change gender, phone and customer variables into 1 or 0 dummies
mydataB$Education<-ifelse(mydataB$Education == "H", 1, 0)
mydataB$Gender <- ifelse(mydataB$Gender == "M", 1, 0)
mydataB$Phone <- ifelse(mydataB$Phone == "Y", 1, 0)
mydataB$Customer <- ifelse(mydataB$Customer == "E", 1, 0)

summary(mydataB)

# change data object name
mydata=mydataB

# looking at correlation among variables
vctCorr = numeric(0)
for (i in names(mydata)){
  cor.result <- cor(as.numeric(mydata$Default), as.numeric(mydata[,i]))
  vctCorr <- c(vctCorr, cor.result)
}
dfrCorr <- vctCorr
names(dfrCorr) <- names(mydata)
dfrCorr

# Split Data into train set and test set
set.seed(123)
smp_size <- floor(0.80 * nrow(mydata))
train_ind <- sample(seq_len(nrow(mydata)), size = smp_size)

train <- mydata[train_ind, ]
test <- mydata[-train_ind, ]

#### MODELLING PROCESS

#We consider the full model as the model containing all second order interactions among the explanatory variables. 
#In the search for model selection, we shall consider all models which are subsets of this full model. 
#For computational reasons, we shall start with the full model and use backward stepwise search by removing one term at a time.

#For this, we define the following function.

subset_select <- function(fit, type = c("AIC", "BIC")) {
  data <- fit$data
  family <- fit$family[[1]]
  
  repeat {
    if (type == "AIC") {
      a <- drop1(fit, k = 2)
    }
    else if (type == "BIC") {
      a <- drop1(fit, k = 2 * log(nrow(data)))
    }
    else {
      stop("NotImplementedError")
    }
    
    a <- a[order(a$AIC), ]  # order in increasing order of AIC
    
    if (rownames(a)[1] == "<none>") {
      # that means all models in previous level attains minimum AIC/BIC/HQ criterion
      fit1 <- glm(new_form1, data = data, family = family)
      fit2 <- glm(new_form2, data = data, family = family)
      fit3 <- glm(new_form3, data = data, family = family)
      
      return(list(fit1, fit2, fit3))
    }
    
    else if (rownames(a)[2] == "<none>") {
      # that means 1st model is current level - something
      # 2nd model is the current level
      # 3rd model could be current level - something or 2nd model in current level
      if (aic2 > a$AIC[3]) {
        new_form3 <- update(formula(fit), paste("~ . -", rownames(a)[3] ))
      } else {
        new_form3 <- new_form2  # the 2nd model in current level beats the 3rd model after removing
      }
      new_form2 <- new_form1
      new_form1 <- update(formula(fit), paste("~ . -", rownames(a)[1] ))
      
      fit1 <- glm(new_form1, data = data, family = family)
      fit2 <- glm(new_form2, data = data, family = family)
      fit3 <- glm(new_form3, data = data, family = family)
      
      return(list(fit1, fit2, fit3))
      
    }
    else if (rownames(a)[3] == "<none>") {
      # current model is 3rd best, For first and 2nd best need to remove the things specified
      new_form3 <- new_form1
      new_form2 <- update(formula(fit), paste("~ . -", rownames(a)[2] ))   
      new_form1 <- update(formula(fit), paste("~ . -", rownames(a)[1] )) 
      
      fit1 <- glm(new_form1, data = data, family = family)
      fit2 <- glm(new_form2, data = data, family = family)
      fit3 <- glm(new_form3, data = data, family = family)
      
      return(list(fit1, fit2, fit3))
      
    }
    
    else {
      new_form1 <- update(formula(fit), paste("~ . -", rownames(a)[1] ))   # selects 3 best models
      new_form2 <- update(formula(fit), paste("~ . -", rownames(a)[2] ))
      new_form3 <- update(formula(fit), paste("~ . -", rownames(a)[3] ))
      fit <- glm(new_form1, data = data, family = family)
    }
    
  }
  
}

#Now, we use this function to obtain stepwise selected models using AIC, BIC and Hannan-Quinn criterion criterion.

# define a scope of models to search from
fit <- glm(Default ~ .^2, data = train, family = "binomial")

# with AIC
print("With AIC criterion")
b <- subset_select(fit, type = "AIC")
print("best model")
summary(b[[1]])
mod1<-b[[1]] # object for Best AIC model
#print("Second best model")
#summary(b[[2]])
#mod2<-b[[2]] 
#print("Third best model")
#summary(b[[3]])
#mod3<-b[[3]] 


print("With BIC criterion")
b <- subset_select(fit, type = "BIC")
print("best model")
summary(b[[1]])
mod4<-b[[1]] # object for best BIC model
#print("Second best model")
#summary(b[[2]])
#mod5<-b[[2]]
#print("Third best model")
#summary(b[[3]])
#mod6<-b[[3]]


# then we select the best AIC and BIC models for prediction
library(pROC)
library(MLmetrics)
# Prediction using Best AIC model on test set data
table(test$Default, ifelse(predict(mod1,test)>0.5,1,0))
Accuracy( ifelse(predict(mod1,test)>0.5,1,0),test$Default)
roc(test$Default,ifelse(predict(mod1,test)>0.5,1,0),plot = TRUE,legacy.axes=TRUE,xlab='FP %', 
    ylab='TP %',lwd=3,col='blue',print.auc=T)
# 68.5% Accuracy

# Prediction using Best BIC model on test set data
table(test$Default, ifelse(predict(mod4,test)>0.5,1,0))
Accuracy( ifelse(predict(mod4,test)>0.5,1,0),test$Default)
roc(test$Default,ifelse(predict(mod4,test)>0.5,1,0),plot = TRUE,legacy.axes=TRUE,xlab='FP %', 
    ylab='TP %',lwd=3,col='blue',print.auc=T)
# 71.5% Accuracy

########## GENERALIZED ADDITIVE MODEL (GAM)
library(mgcv)

# Because gam function from mgcv package does not accept factor variables, re-convert columns to numeric
#train$Gender= as.numeric(as.factor(train$Gender))
#train$Education= as.numeric(as.factor(train$Education))
#train$Phone= as.numeric(as.factor(train$Phone))
#train$Customer= as.numeric(as.factor(train$Customer))

#---GAM model
gamMod <- gam(Default ~ s(Income,bs="tp") + s(Loan,bs="tp") + s(Age,bs="tp") + (Gender) + (Education) + 
          s(Children,bs="tp",k=5) + s(Employment,bs="tp") + s(Adress,bs="tp") + (Phone) + (Customer) + (Term) + 
           s(Limit,bs="tp") + te(Income,Loan,bs="tp") + te(Income,Age,bs="tp") + te(Income,Children,bs="tp") + 
           te(Income,Adress,bs="tp") + (Income:Customer) + (Income:Term) + te(Income,Limit,bs="tp") + 
           s(Loan,Age,bs="tp") + (Loan:Gender) + te(Loan,Employment,bs="tp") + te(Loan,Adress,bs="tp") + 
            (Loan:Customer) + (Age:Customer) + (Age:Term) + (Gender:Education) + (Gender:Limit) + 
             (Education:Children) + (Education:Phone) + (Children:Customer) + (Children:Term) + 
          te(Employment,Adress,bs="tp") + te(Employment,Limit,bs="tp") + (Adress:Term) + 
           te(Adress,Limit,bs="tp") + (Phone:Term) + (Phone:Limit), data = train, family = "binomial")

summary(gamMod)
logLik.gam(gamMod) # penalised likelihood maximisation based on treating penalised 
# e.g spline coefficients as random then integrating them out

# Prediction using GAM model on test data

# First re-convert columns of the test set to numeric
#test$Gender= as.numeric(as.factor(test$Gender))
#test$Education= as.numeric(as.factor(test$Education))
#test$Phone= as.numeric(as.factor(test$Phone))
#test$Customer= as.numeric(as.factor(test$Customer))
#-----predictions
table(test$Default, ifelse(predict(gamMod,test)>0.5,1,0))
Accuracy( ifelse(predict(gamMod,test)>0.5,1,0),test$Default)
roc(test$Default,ifelse(predict(gamMod,test)>0.5,1,0),plot = TRUE,legacy.axes=TRUE,xlab='FP %', 
    ylab='TP %',lwd=3,col='blue',print.auc=T)

# 72% Accuracy


#########  PENALISED ESTIMATION MODEL SEARCH AND SELECTION (LASSO)
library(glmnet)
library(caret)

y = unlist(train["Default"])
x = train %>%
  dplyr::select(-Default) %>%
  mutate(Gender = as.numeric(as.factor(Gender)), Education = as.numeric(as.factor(Education)),
         Phone = as.numeric(as.factor(Phone)), Customer = as.numeric(as.factor(Customer)),
         Gender = ifelse(Gender == "1", 1, 0),
         Phone = ifelse(Phone == "1", 1, 0),
         Customer = ifelse(Customer == "1", 1, 0)) %>% as.matrix()

# Lasso regression and model selection
# set lambda first
lambdas <- 10^seq(3, -2, by = -.1)

f2 = cv.glmnet(x,y,alpha = 1, lambda = lambdas, nfolds = 15, family = "binomial")
f2$lambda.min
coef(f2, s=f2$lambda.min)
plot(f2)

# Based on the above Lasso model selection procedure, 8 predictor variables were selected
# a traditional glm model for binary response was run with the selected variables on training data.
glmlasso<-glm(Default ~ Income + Age + Education + Children + Employment + 
              Customer + Term + Limit, data = train, family = "binomial")
summary(glmlasso)

## Prediction using LASSO selected model on test data
table(test$Default, ifelse(predict(glmlasso,test)>0.5,1,0))
Accuracy( ifelse(predict(glmlasso,test)>0.5,1,0),test$Default)
roc(test$Default,ifelse(predict(glmlasso,test)>0.5,1,0),plot = TRUE,legacy.axes=TRUE,xlab='FP %', 
    ylab='TP %',lwd=3,col='blue',print.auc=T)

# 71.5% Accuracy and confusion matrix is same as model selected by BIC criterion



# B.2

library(tmg)
source("PostAIC.R")

# Main effects model Search based on PostAIC function and 99% confidence intervals
PostAIC(mydata$Default,mydata[,c("Income","Loan","Employment","Limit","Phone",
                                   "Age","Gender","Customer","Adress","Education","Term",
                                   "Children")], model.set='allsubsets',quant = 0.99,family=binomial)

# Naive confidence intervals of 99% for the Post-AIC selected main effects model
maineff<-glm(Default ~ Income + Employment + Limit + Age + Education + Term + Children, data = mydata, family = "binomial")
summary(maineff)

std=coef(summary(maineff))[,"Std. Error"]
maineff$coefficients[1] + c(-1,1) * qnorm(0.995) * std[1]
maineff$coefficients[2] + c(-1,1) * qnorm(0.995) * std[2]
maineff$coefficients[3] + c(-1,1) * qnorm(0.995) * std[3]
maineff$coefficients[4] + c(-1,1) * qnorm(0.995) * std[4]
maineff$coefficients[5] + c(-1,1) * qnorm(0.995) * std[5]
maineff$coefficients[6] + c(-1,1) * qnorm(0.995) * std[6]
maineff$coefficients[7] + c(-1,1) * qnorm(0.995) * std[7]
maineff$coefficients[8] + c(-1,1) * qnorm(0.995) * std[8]


###################### QUESTION C

DataQC = read.table("bikestations.txt")
digitsum = function(x) sum(floor(x/10^(0:(nchar(x)-1)))%%10)
studentnumber=0637968 # fill in your student number here, this is an example!
mysum = digitsum(studentnumber)
Y = DataQC[,mysum]
X = DataQC[,-mysum]

# import libraries
library(tidyverse)
library(broom)
library(glmnet)
library(ensr)
library(ensr)
library(glmnetUtils)

# First convert the data to matrix and applying with 7-fold cross validation 
Y = as.matrix(Y)
X = as.matrix(X) 

# Defining lambdas that would be used
lambdas <- 10^seq(3, -2, by = -.1)

####--------------RIDGE REGRESSION
#setting alpha=0 produces ridge estimators
cv_fit <- cv.glmnet(X, Y, alpha = 0, lambda = lambdas,nfolds = 7, family="poisson")
ridge_coef<-coef(cv_fit,s= cv_fit$lambda.min)
print(ridge_coef)
plot(cv_fit)
title("Poisson Ridge", line = 2.5)

###---------------LASSO REGRESSION
# Setting alpha = 1 implements lasso regression
lasso_reg <- cv.glmnet(X, Y, alpha = 1, lambda = lambdas, standardize = TRUE, nfolds = 7, family="poisson")
lasso_coef<-coef(lasso_reg,s=lasso_reg$lambda.min)
print(lasso_coef)
plot(lasso_reg)
title("Poisson Lasso", line = 2.5)

###----------ELASTIC NET ESTIMATOR 1
ensr_obj <- ensr(X,Y, standardize = FALSE, nfolds = 7, family="poisson")
ensr_obj_summary <- summary(object = ensr_obj)
ensr_obj_summary[cvm == min(cvm)]
# As from the above output,it is evident that at index 16 has lowest cross validation error 
# and at this index alpha is 0.8333333
#so finding the coef of that model
evap_coef  <- coef(ensr_obj[[16]], s = 0.01)
print(evap_coef)
#plot(ensr_obj)
#title("Elastic Net Estimator 1", line = 2.5)

###----------ELASTIC NET ESTIMATOR 2
ensr_obj1 <- cv.glmnet(X, Y, alpha = 0.5, standardize = TRUE, nfolds = 7, family="poisson")
ensr_coef1<-coef(ensr_obj1,s=lasso_reg$lambda.min)
print(ensr_coef1)
plot(ensr_obj1)
title("Elastic Net Estimator 2", line = 2.5)

### PREPARING TABLE OF COEFF.
library(data.table)
DT = data.table(as.matrix(ridge_coef),as.matrix(lasso_coef),as.matrix(evap_coef),as.matrix(ensr_coef1),keep.rownames = FALSE)
DT
# write.csv()

### FINDING THE PENALTY FOR EACH MODEL
#It is the minimum value of lambda corresponding to the best fit model
opt_lambda_ridge <- cv_fit$lambda.min
opt_lambda_ridge
opt_lambda_lasso <- lasso_reg$lambda.min
opt_lambda_lasso
opt_lambda_ensr1<-ensr_obj_summary[cvm == min(cvm)]$lambda
opt_lambda_ensr1
opt_lambda_ensr2<-ensr_obj1$lambda.min
opt_lambda_ensr2




