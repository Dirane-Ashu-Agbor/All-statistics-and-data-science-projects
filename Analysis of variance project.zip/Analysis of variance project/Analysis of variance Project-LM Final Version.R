#=================================#
# Linear Models Project           #
# December 2020                   #
# Team 07                         # 
# Ricardo Castañeda - r0731529   #
# Dirane Ashu Agbor - r0637968    #
# Kendall Brown - r0773111        #
# Yang He - r0769477              #
# Yongjian Li - r0767872          # 
#=================================#
rm(list = ls())
par()


## Libraries
library(rio)
library(tidyverse)
library(car)
library(sp)
library(devtools)
library(qqplotr)
library(MASS)
library(userfriendlyscience)
library(psych)
library(car)
library(e1071)
library(RVAideMemoire)

## Importing Dataset
salary=read.table('/Users/diran/Downloads/Linear Models/Assignment project/salarydata.txt',
                  sep=",",skip = 25)[,-1]
colnames(salary)=c("Salary","Gender","Education")

attach(salary) # Remember to detach!!!! Otherwise it will ruin your other analysis 
str(salary)
sum(is.na(salary)) # No missing data

range(salary$Salary)

#===============================# 
# 1. Exploratory Data Analysis  #
#===============================#

## Frequency Tables
freq.salary<-table(Gender,Education)
mean.freq.salary <-tapply(Salary,list(Gender,Education), mean)

freq.salary #Treatment Frequency
round(mean.freq.salary, digits=2) #Means in the treatments

## Boxplots  

## Cook's Distance ##
Salary.modl<-aov(Salary~Gender*Education,data = salary)
plot(cooks.distance(Salary.modl), main = "Cook's Distance")
which(cooks.distance(Salary.modl) > 0.08) #85

salary[which(cooks.distance(Salary.modl) > 0.08), ]
salary$interact = interaction(salary$Gender, salary$Education)
outlier_obs = salary[which(cooks.distance(Salary.modl) > 0.08), ]


#Boxplot, Grouped By Sex
ggplot(salary, aes(x=Gender, y=Salary, fill=Gender))+
  geom_jitter(position=position_jitter(0)) +
  geom_boxplot(colour="black", alpha=1) + 
  geom_point(data=outlier_obs, cex=4, colour="red", show.legend = FALSE) +
  stat_summary(fun=mean, geom="point", size=3, colour="yellow", show.legend = FALSE) +
  stat_summary(fun=mean, geom="point", size=3, colour="yellow", show.legend = FALSE)+ 
  labs(title = paste("Salary in thousands of dollars per year",
                     "Grouped By Sex",
                     sep = "\n"),
       x = "Gender \n (variable = 'Gender')",
       y = "Salary") +  
  # change background + legend theme, and axis type
  theme(
    panel.background = element_rect(fill = "white"),         # Set plot background to white
    legend.key  = element_rect(fill = "white"),              # Set legend item backgrounds to white
    axis.line.x = element_line(colour = "black", size = 1),  # Add line to x axis
    axis.line.y = element_line(colour = "black", size = 1),  # Add line to y axis
    axis.title.x=element_text(vjust=2.5,                     # X axis title
                              size=14),                
    axis.title.y=element_text(size=14),                      # Y axis title
    # X axis text
    axis.text.x=element_text(size=12,
                             vjust=.55), 
    # Y axis text
    axis.text.y=element_text(size=12),                        
    legend.text = element_text(size=12),
    legend.title = element_text(size=14)
  )

######  Boxplot, Grouped By Education ########

ggplot(salary, aes(x=Education, y=Salary, fill=Education))  + 
  geom_jitter(position=position_jitter(0)) +
  theme(axis.text.x=element_blank()) +
  geom_point(data=outlier_obs, cex=4, colour="red", show.legend = FALSE) +
  geom_boxplot(colour="black", alpha=1) +
  stat_summary(fun=mean, geom="point", size=3, colour="yellow", show.legend = FALSE)+ 
  labs(title = paste("Salary in thousands of dollars per year",
                     "Grouped By Education ",
                     sep = "\n"),
       x = "Education Level \n (variable = 'Education')",
       y = "Salary") +  
  # change background + legend theme, and axis type
  theme(
    panel.background = element_rect(fill = "white"),         # Set plot background to white
    legend.key  = element_rect(fill = "white"),              # Set legend item backgrounds to white
    axis.line.x = element_line(colour = "black", size = 1),  # Add line to x axis
    axis.line.y = element_line(colour = "black", size = 1),  # Add line to y axis
    axis.title.x=element_text(vjust=2.5,                     # X axis title
                              size=14),                
    axis.title.y=element_text(size=14),                      # Y axis title
    # X axis text
    axis.text.x=element_text(size=12,                       
                             angle = 30,
                             vjust=.55), 
    # Y axis text
    axis.text.y=element_text(size=12),                        
    legend.text = element_text(size=12),
    legend.title = element_text(size=14)
  )

##### Descriptive Statistics for Interaction #####
# for dependent variable social anxiety, compute within each ANOVA treatment:
#   - mean
#   - standard deviation 
#   - standard error 
#   - 95% confidence Interval around treatment mean

salary.CI <-  salary %>%
  group_by(Gender, Education) %>%
  summarise(mean.SA = mean(Salary, na.rm = TRUE),
            sd.SA = sd(Salary, na.rm = TRUE),
            n.SA = n()) %>%
  mutate(se.SA = sd.SA / sqrt(n.SA),
         lower.ci.SA = mean.SA - qt(1 - (0.05 / 2), n.SA - 1) * se.SA,
         upper.ci.SA = mean.SA + qt(1 - (0.05 / 2), n.SA - 1) * se.SA)

# define position argument to obtain non-overlapping CI bars
pd <- position_dodge(width = 0.2)


# 2) create two-way (group*sex) interaction line plot
# with 95% confidence intervals around ANOVA treatment means

p2 <- ggplot(salary.CI, 
             aes(y= mean.SA, x= Education, group = Gender)) +
  geom_line(aes(linetype = Gender), size=.7, position =  pd) + 
  geom_point(size=4, position = pd) +            
  geom_point(size=3, color = "white", position = pd) + 
  geom_errorbar(aes(ymax = upper.ci.SA , ymin= lower.ci.SA), width=.2, position = pd) + 
  # prettify plot!
  labs(title = paste("Salary",
                     "Within Two-Way ANOVA Treatments - ",
                     "Error Bars Represent 95% Confidence Intervals",
                     sep = "\n"),
       x = "Education level \n (variable = 'Education')",
       y = "Salary") +
  # Modify Legend
  guides(linetype = guide_legend("Gender (variable = 'gender')"))  + 
  # change background + legend theme, and axis type
  theme(
    panel.background = element_rect(fill = "white"),         # Set plot background to white
    legend.key  = element_rect(fill = "white"),              # Set legend item backgrounds to white
    axis.line.x = element_line(colour = "black", size = 1),  # Add line to x axis
    axis.line.y = element_line(colour = "black", size = 1),  # Add line to y axis
    axis.title.x=element_text(vjust=2.5,                     # X axis title
                              size=14),                
    axis.title.y=element_text(size=14),                      # Y axis title
    # X axis text
    axis.text.x=element_text(size=12,                       
                             angle = 30,
                             vjust=.55), 
    # Y axis text
    axis.text.y=element_text(size=12),                        
    legend.text = element_text(size=12),
    legend.title = element_text(size=14)
  )
p2


##### Grouped Boxplot ######
p1 <- ggplot(salary, 
             aes(y= Salary, x=Education, fill = Gender))  + 
  stat_boxplot(geom = "errorbar", stat_params = list(width = 0.5,size = 5.0)) + 
  geom_boxplot(colour="black", alpha=1, lwd=0.2) + 
  # prettify plot!
  labs(title = paste("Salary level",
                     "Within Two-Way ANOVA Treatments - ",
                     "Whiskers Extend from First/Third quartile",
                     "To Smallest/Largest Value -/+ 1.5 * IQR",
                     sep = "\n"),
       x = "Education level \n (variable = 'Education')",
       y = "Salary") + 
  # change background + legend theme, and axis type
  theme(
    panel.background = element_rect(fill = "white"),         # Set plot background to white
    legend.key  = element_rect(fill = "white"),              # Set legend item backgrounds to white
    axis.line.x = element_line(colour = "black", size = 1),  # Add line to x axis
    axis.line.y = element_line(colour = "black", size = 1),  # Add line to y axis
    axis.title.x=element_text(vjust=2.5,                     # X axis title
                              size=14),                
    axis.title.y=element_text(size=14),                      # Y axis title
    # X axis text
    axis.text.x=element_text(size=12,                       
                             angle = 30,
                             vjust=.55), 
    # Y axis text
    axis.text.y=element_text(size=12),                        
    legend.text = element_text(size=12),
    legend.title = element_text(size=14)
  )
p1


## Descriptive statistics overall ##

summary_stats <- as_tibble(
  salary %>% 
    group_by(interact) %>%
    summarize(mean = round(mean(Salary), 3),
              var = round(var(Salary), 3),
              N = n()))
summary_stats


################## Stripchart per Education, Gender ################

# Gender
stripchart(salary$Salary ~ salary$Gender,
           vertical = F, xlab = 'Salary in thousands of dollars per year', las=1)
meanvec <- tapply(salary$Salary,salary$Gender, mean)
abline(h=1:2, lty=3, col="black")
points(meanvec, 1:2, pch=16, col="red", cex=2)

# Education
par(mar=c(3,10,3,3)+1.)
stripchart(salary$Salary ~ salary$Education,
           vertical = F, xlab = 'Salary in thousands of dollars per year', las=1)
meanvec <- tapply(salary$Salary,salary$Education, mean)
abline(h=1:2, lty=3, col="black")
points(meanvec, 1:2, pch=16, col="red", cex=2)

detach(salary)

#=======================================#
# 2. Anova model: Cell Mean Model       #
#=======================================#

# Cell Mean Model as Regession Model
salary.lm.unbalanced = lm(Salary ~ -1 + Gender : Education, data = salary)
summary(salary.lm.unbalanced)

# testing for factor gender by creating a contrast matrix
cmgender.unbal = matrix(c(-48/72, 18/60, -24/72, 42/60), nrow = 1, ncol = 4, byrow = T)
gender.const.unbal = glht(salary.lm.unbalanced , linfct = cmgender.unbal)
summary(gender.const.unbal, test = Ftest())

# Type I SS in R (Confirmation)

Salary.modl<-aov(Salary~Gender*Education,data = salary)
Salary.modl.summary<-summary(Salary.modl)
Salary.modl.summary

foo = aov(Salary~Gender+ Education,data = salary)
summary(foo)



#=========================#
#  Multiple Comparison    #
#=========================#

tukey <- TukeyHSD(aov(Salary ~ Education, data = salary, contrasts = list(Education ="contr.sum")))
plot(tukey, cex.axis=0.4)





#=============================================================#
# 2. Factor Effects Model - alternative regession approach    #
#=============================================================#

# Creating the indicator variables
salary.regre.unbal = as.data.frame(model.matrix(~ Gender * Education, salary, contrasts = list(Gender = 'contr.sum', Education = 'contr.sum'))[,2:4])
salary.regre.unbal$Salary = salary$Salary
salary.regre.unbal

# Correlation matrix of the predictors
dummy.cor.unbal = cor(salary.regre.unbal[, 1:3])
corrplot::corrplot(dummy.cor.unbal, method = 'circle')

# Model for factor Gender
salary.unbal.a = lm(Salary ~ Gender1, data = salary.regre.unbal)
summary(salary.unbal.a)

# Model for factor Gender and Education
salary.unbal.ab = lm(Salary ~ Gender1 + Education1, data = salary.regre.unbal)
summary(salary.unbal.ab)

# Full Model
salary.unbal.full = lm(Salary ~ Gender1 + Education1 + Gender1:Education1 , data = salary.regre.unbal)
summary(salary.unbal.full)

# Empty model
salary.unbal.empty = lm(Salary ~ 1, data = salary.regre.unbal)

# Sequential Type I by hand
anova(salary.unbal.empty, salary.unbal.a, salary.unbal.ab, salary.unbal.full)

#======================#
# 3. Model Validation  #
#======================#

#=======================#
# Analysis of residuals #
#=======================#

## Fitted values vs Studentized Residuals
plot(fitted.values(Salary.modl),rstandard(Salary.modl),
     xlab="Fitted values",
     ylab="Studentized residuals",
     main="Residuals vs fitted values plot")
abline(h=0,lty="dashed")

x<-as.numeric(salary$Gender)
plot(x,rstandard(Salary.modl), xlab="Observed values",
     ylab="Studentized residuals",
     main="Residuals vs factor levels plot - Gender",axes=F)

axis(side=1, at = c(1,2), labels = c("Female","Male"))
axis(side=2)
abline(h=0,lty="dashed")

x2<-as.numeric(salary$Education)

plot(x2,rstandard(Salary.modl), xlab="Observed values",
     ylab="Studentized residuals",
     main="Residuals vs factor levels plot - Education",axes=F)

axis(side=1, at = c(1,2), labels = c("Degree","No Degree"))
axis(side=2)
abline(h=0,lty="dashed")

## Sequence Plot for independence 
attach(salary)
n_i=c(length(Salary[Gender=="Male"]),length(Salary[Gender=="Female"]))
n_T=sum(n_i)

plot(rstandard(Salary.modl)[-c(1)],rstandard(Salary.modl)[-c(n_T)],
     xlab="Studentized residuals at 1 lag",
     ylab="Studentized residuals",
     main="Sequence plot")
abline(a=0,b=1,lty="dashed")
detach(salary)

#==================#
#  Normality       # 
#==================#

std.res<-residuals(Salary.modl)
std.res<- stdres(Salary.modl) #Standardized Residuals
std.res<-data.frame(std.res)


#All bands
gg2 <- ggplot(data = std.res, mapping = aes(sample = std.res)) +
  geom_qq_band(bandType = "ks", mapping = aes(fill = "KS"), alpha = 0.5) +
  geom_qq_band(bandType = "ts", mapping = aes(fill = "TS"), alpha = 0.5) +
  geom_qq_band(bandType = "pointwise", mapping = aes(fill = "Normal"), alpha = 0.5) +
  geom_qq_band(bandType = "boot", mapping = aes(fill = "Bootstrap"), alpha = 0.5) +
  stat_qq_line() +
  stat_qq_point() +
  labs(x = "Theoretical Quantiles", y = "Sample Quantiles") +
  scale_fill_discrete("Bandtype")
gg2

## Shapiro - Wilk Test
shapiro.test(Salary.modl$residuals) #Normality is met 

## Kolmogorov Test
ks.test(Salary.modl$residuals,"pnorm",alternative="two.sided", 
        mean = mean(Salary.modl$residuals), sd = sd(Salary.modl$residuals))

# D = 0.045062, p-value = 0.9515
# alternative hypothesis: two-sided


#=======================================#
# Checking the homogeneity of variances #
#=======================================#

##Checking The model
leveneTest(Salary ~ Gender*Education, salary) # Accepts H0

##Checking Individual Factors
leveneTest(Salary ~ Gender, salary) # Accepts H0
leveneTest(Salary ~ Education, salary) # Accepts H0

#===========================================#
# Testing independece - Durbin Watson test  #
#===========================================#

durbinWatsonTest(Salary.modl, alternative="two.sided", data=salary)

#====================#
# Testing Outliers   #
#====================#

pvalue_outliers = NULL
r.al=2
nT.al<-132
for(i in 1:nT.al)
  pvalue_outliers[i]=1-pt(abs(rstudent(Salary.modl)[i]),
                          + nT.al-r.al-1)

pvalue_outliers[pvalue_outliers>(0.05/(nT.al))]=1
Stud.Deleted.Res=rstudent(Salary.modl)
Outlier.p.value=pvalue_outliers
out.salary<-data.frame(Stud.Deleted.Res,
                       + Outlier.p.value)
out.salary #No Outliers encountered 

which(out.salary > 2)
which(out.salary < -2)

high.res<- out.salary[c(38,47,62,64,85,105,114,121),] 
high.res

## Cook's Distance
plot(cooks.distance(Salary.modl), main = "Cook's Distance")
which(cooks.distance(Salary.modl) > 0.08) #85

salary[which(cooks.distance(Salary.modl) > 0.08), ]

