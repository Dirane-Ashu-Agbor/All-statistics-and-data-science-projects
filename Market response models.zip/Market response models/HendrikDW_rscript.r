setwd("~/Documents/diran/KUL/MASTER OF STATISTICS/2nd year/first sem/Marketing Response Models/homework 2")

####  LIBRARIES ####
library(GGally)
library(zoo)
library(readxl)
library(xts)
library(Hmisc)
library(msm)
library(car)


#### DATA PREPARATION ####
data <- read_excel("assign2.xlsx")



########### QUESTION 1 ###############

#AXE

#creating lagged and lead dummies
AH <- data.frame(data)
attach(AH)
AXElagdummydiscount <- dummy_Post.dip
AXEleaddummydiscount <- dummy_Pre.dip
AH <- data.frame(AH, AXElagdummydiscount, AXEleaddummydiscount)


AXElagdummyfeature <-  Lag(Axe_Feat,1)
AXEleaddummyfeature <- Lag(Axe_Feat, -1)
AH <- data.frame(AH, AXElagdummyfeature, AXEleaddummyfeature)

AXElagdummydisplay <-  Lag(Axe_Disp,1)
AXEleaddummydisplay <- Lag(Axe_Disp, -1)
AH <- data.frame(AH, AXElagdummydisplay, AXEleaddummydisplay)

AXElagdummydispfeature <-  Lag(Axe_D.F,1)
AXEleaddummydispfeature <- Lag(Axe_D.F, -1)
AH <- data.frame(AH, AXElagdummydispfeature, AXEleaddummydispfeature)



Q1AXE1 <- lm(AHCategorySales ~ dummy_discountOver15 + AXElagdummydiscount + AXEleaddummydiscount, data=AH)
summary(Q1AXE1)
#no delta

Q1AXE2 <- lm(AHCategorySales ~ Axe_Feat + AXElagdummyfeature + AXEleaddummyfeature, data=AH)
summary(Q1AXE2)
#no delta

Q1AXE3 <- lm(AHCategorySales ~ Axe_Disp + AXElagdummydisplay + AXEleaddummydisplay, data=AH)
summary(Q1AXE3)
#no delta

Q1AXE4 <- lm(AHCategorySales ~ Axe_D.F + AXElagdummydispfeature + AXEleaddummydispfeature, data=AH)
summary(Q1AXE4)
#No delta





#REXONA

#creating lagged and lead dummies
names(AH)
REXlagdummydiscount <- dummy_RexPost.dip
REXleaddummydiscount <- dummy_RexPre.dip
AH <- data.frame(AH, REXlagdummydiscount, REXleaddummydiscount)

REXlagdummyfeature <-  Lag(Rex_Feat,1)
REXleaddummyfeature <- Lag(Rex_Feat, -1)
AH <- data.frame(AH, REXlagdummyfeature, REXleaddummyfeature)

REXlagdummydisplay <-  Lag(Rex_Disp,1)
REXleaddummydisplay <- Lag(Rex_Disp, -1)
AH <- data.frame(AH, REXlagdummydisplay, REXleaddummydisplay)

REXlagdummydispfeature <-  Lag(Rex_D.F,1)
REXleaddummydispfeature <- Lag(Rex_D.F, -1)
AH <- data.frame(AH, REXlagdummydispfeature, REXleaddummydispfeature)


Q1REX1 <- lm(AHCategorySales ~ dummy_RexdiscountOver15 + REXlagdummydiscount + REXleaddummydiscount, data=AH)
summary(Q1REX1)

Q1REX2 <- lm(AHCategorySales ~ Rex_Feat + REXlagdummyfeature + AXEleaddummyfeature, data=AH)
summary(Q1REX2)

Q1REX3 <- lm(AHCategorySales ~ Rex_Disp + REXlagdummydisplay + REXleaddummydisplay, data=AH)
summary(Q1REX3)

Q1REX4 <- lm(AHCategorySales ~ Rex_D.F + REXlagdummydispfeature + REXleaddummydispfeature, data=AH)
summary(Q1REX4)



#add two period lead for display and discount
REXlead2dummydiscount <- Lag(dummy_RexdiscountOver15, 2)
AH <- data.frame(AH, REXlead2dummydiscount)

Q1REX11 <- lm(AHCategorySales ~ dummy_RexdiscountOver15 + REXleaddummydiscount + REXlead2dummydiscount, data=AH)
summary(Q1REX11)

REXlead2dummydisplay <- Lag(Rex_Disp, 2)
AH <- data.frame(AH,REXlead2dummydisplay)

Q1REX33 <- lm(AHCategorySales ~ Rex_Disp + REXleaddummydisplay + REXlead2dummydisplay, data=AH)
summary(Q1REX33)

#we leave this out since no second lag is significant.




########### QUESTION 2 ###############

# AXE

Q2AXE1 <- lm(AxeSales ~ dummy_discountOver15 + AXElagdummydiscount + AXEleaddummydiscount, data=AH)
summary(Q2AXE1)

Q2AXE2 <- lm(AxeSales ~ Axe_Feat + AXElagdummyfeature + AXEleaddummyfeature, data=AH)
summary(Q2AXE2)

Q2AXE3 <- lm(AxeSales ~ Axe_Disp + AXElagdummydisplay + AXEleaddummydisplay, data=AH)
summary(Q2AXE3)

Q2AXE4 <- lm(AxeSales ~ Axe_D.F + AXElagdummydispfeature + AXEleaddummydispfeature, data=AH)
summary(Q2AXE4)


# REXONA
Q2REX1 <- lm(RexonaSales ~ dummy_RexdiscountOver15 + REXlagdummydiscount + REXleaddummydiscount, data=AH)
summary(Q2REX1)

Q2REX2 <- lm(RexonaSales ~ Rex_Feat + REXlagdummyfeature + AXEleaddummyfeature, data=AH)
summary(Q2REX2)

Q2REX3 <- lm(RexonaSales ~ Rex_Disp + REXlagdummydisplay + REXleaddummydisplay, data=AH)
summary(Q2REX3)

Q2REX4 <- lm(RexonaSales ~ Rex_D.F + REXlagdummydispfeature + REXleaddummydispfeature, data=AH)
summary(Q2REX4)
#no delta



########### QUESTION 3 ###############

#rexone is largest brand in volume

Q3model <- lm(RexonaSales ~ dummy_RexdiscountOver15 + Rex_Feat + Rex_Disp + Rex_D.F, data=AH)
summary(Q3model)


#all significant, but which is most effective: delta rule
#B1 and B2
a <- vcov(Q3model)
DM <- deltaMethod(Q3model, "b1-b4", parameterNames= paste("b", 0:4, sep=""))
summary(DM)
tstatistic <- DM$Estimate/DM$SE

p.value <- 2*pt(-abs(tstatistic), df=length(AH)-1)
p.value




# Instrument 1 (Price promotion dynamic effects)
Q3I1 <-lm(RexonaSales ~ dummy_RexdiscountOver15 + REXlagdummydiscount + REXleaddummydiscount, data=AH)
summary(Q3I1)

# Instrument 2 (Features dynamic effects)
Q3I2 <-lm(RexonaSales ~ Rex_Feat + REXlagdummyfeature + REXleaddummyfeature, data=AH)
summary(Q3I2)

# Instrument 3 (Displays dynamic effects)
Q3I3 <-lm(RexonaSales ~ Rex_Disp + REXlagdummydisplay + REXleaddummydisplay, data=AH)
summary(Q3I3)

# Instrument 4 (D+F dynamic effects)
Q3I4 <-lm(RexonaSales ~ Rex_D.F + REXlagdummydispfeature + REXleaddummydispfeature, data=AH)
summary(Q3I4)



DMmodel <- lm(RexonaSales ~ dummy_RexdiscountOver15 + REXlagdummydiscount + REXleaddummydiscount + 
                Rex_Feat + REXlagdummyfeature + REXleaddummyfeature + 
                Rex_Disp + REXlagdummydisplay + REXleaddummydisplay +
                Rex_D.F + REXlagdummydispfeature + REXleaddummydispfeature, data=AH)
summary(DMmodel)

DMQ3 <- deltaMethod(DMmodel, "(b1+b2+b3)- (b4+b5+b6) - (b7+b8+b9) - (b10+b11+b12)", parameterNames= paste("b", 0:12, sep=""))
tstatisticQ3 <- DMQ3$Estimate/DMQ3$SE
2*pt(-abs(tstatisticQ3), df=109)

#this is also the case when accounting for dynamic effects.



########### QUESTION 4 ###############

#REXONA
summary(Q3I1)

#AXE
modelQ4AXE <-lm(AxeSales ~ dummy_discountOver15 + AXEleaddummydiscount + AXElagdummydiscount, data=AH)
summary(modelQ4AXE)

#similar to question on assignment 3??
#then we stack the data like panel data



names(AH)

modelQ4 <- lm(AHCategorySales ~ Axe_discount_dummy + Rexona_discount_dummy, data = AH )
summary(modelQ4)

Axe_discount_dummy <- AH$dummy_discountOver15
Rexona_discount_dummy <- AH$dummy_RexdiscountOver15

DMQ4_1 <- deltaMethod(test, "b2-b1", parameterNames= paste("b", 0:2, sep=""))
summary(DMQ4_1)
tstatisticQ4_1 <- DMQ4_1$Estimate/DMQ4_1$SE
2*pt(-abs(tstatisticQ4_1), df=length(AH)-1)






#number of lags is square root of n -> 12??

#GRANGER CAUSALITY

BASEMODEL <- lm(AHCategorySales ~ AHCategorySaleslag1+ AHCategorySaleslag2, data=AH)

library(lmtest)
grangertest(AHCategorySales ~ X8X4_FEAT, order = 10, data = AH)
grangertest(AHCategorySales ~ Dove_FEAT, order = 10, data = AH)
grangertest(AHCategorySales ~ Vogue_FEAT, order = 10, data = AH)
grangertest(AHCategorySales ~ Fa_FEAT, order = 10, data = AH)
grangertest(AHCategorySales ~ Nivea_FEAT, order = 10, data = AH)
grangertest(AHCategorySales ~ Sanex_FEAT, order = 10, data = AH)


#none explains sufficient variation in our categorysales



# Second procedure = Delta rule method
#first we fit a regression model with every brand included

modelQ5 <- lm(AHCategorySales ~ X8X4_FEAT+Dove_FEAT+Vogue_FEAT+Fa_FEAT+Nivea_FEAT+Sanex_FEAT, data = AH)
summary(modelQ5)

DMQ5 <- deltaMethod(modelQ5, "b3-b1", parameterNames= paste("b", 0:6, sep=""))
summary(DMQ5)
tstatisticQ5 <- DMQ5$Estimate/DMQ5$SE
2*pt(-abs(tstatisticQ5), df=length(AH)-1)
#normally, if more than one would be significant, we would compare their strength by using delta method
#in this case, only vogue is significant.
