# manually upload data into R
setwd("C:/Users/diran/Downloads/Multivariate Statistics/Assignment 2")
load("spamdata.Rdata")
mydata<-spamdata
colnames(mydata)
table(mydata$spam)

head(mydata,4)

#define binary dependent variable that equals 1 for "spam" and 0 "no spam"
mydata$spam<-factor(ifelse(mydata$spam==1,"spam","no_spam"))
head(mydata,4)

#create train and test set
set.seed(123) # so that results can be replicated afterwards
trainsize<-2500 # training set size 2500 and the remainder test set size = 2101
train = sample(nrow(mydata), trainsize)
data.train<-mydata[train,]
data.test<-mydata[-train,]


library(tree)
theme_set(theme_classic())


# section 1 

##########################
#classification trees
#########################

#grow complex tree on training set using deviance as criterion
tree.mod=tree(spam~.,data.train,control=tree.control(nobs=2500,minsize=2,mincut=1),split="deviance")
summary(tree.mod)

#plot tree
plot(tree.mod)
text(tree.mod,pretty=0,cex=1.4)

#use cross-validation to select tuning parameter for pruning the tree
set.seed(123)
cv.out=cv.tree(tree.mod,K=5)
par(cex=1.4)
plot(cv.out$size,cv.out$dev,type='b')

#prune the tree
prune.mod=prune.tree(tree.mod,best=11)
plot(prune.mod)
text(prune.mod,pretty=0)

# functions to estimate classification errors
err<-function(observed,prob,cutoff)
{tab<-table(observed,ifelse(prob>=0.5,1,0))
err<-1-sum(diag(tab))/sum(tab)
return(err)
}

err2<-function(observed,predicted)
{tab<-table(observed,predicted)
err2<-1-sum(diag(tab))/sum(tab)
return(err2)
}

#make predictions on training and test set using the unpruned tree
pred.train<-predict(tree.mod,newdata=data.train)
err(data.train$spam,pred.train[,2],cutoff=0.5)
pred.test<-predict(tree.mod,newdata=data.test)
err(data.test$spam,pred.test[,2],cutoff=0.5)

#make predictions on training and test set using the pruned tree
pred.train<-predict(prune.mod,newdata=data.train)
err(data.train$spam,pred.train[,2],cutoff=0.5)
pred.test<-predict(prune.mod,newdata=data.test)
err(data.test$spam,pred.test[,2],cutoff=0.5)



# Section 2

##########################
# Linear Discriminant Analysis LDA
#########################

# load libraries
library("MASS") # LDA
library(heplots)
library(candisc)
#library("biotools") # Box M test
#library("Hotelling") # Hotellings' test
#library(pROC) #ROC curve


# First center predictor variables to have 0 sample mean. We do not rescale to have unit variance

# centering with 'scale()'
center_scale <- function(x) {
  scale(x, scale = FALSE)
}                          

library(tidyverse)
y_variable<-mydata %>% dplyr::select(spam)
x_variables<-mydata %>% dplyr::select(-spam)

centered_variables<-center_scale(x_variables)

mydataLDA<-cbind(y_variable,centered_variables)

#define binary dependent variable that equals 2 for "spam" and 1 "no spam"
mydataLDA$spam<-factor(ifelse(mydataLDA$spam=="spam",2,1))
head(mydataLDA,4)

#library(caret)

# Estimate preprocessing parameters
#preproc.param <- data.train %>% preProcess(method = c("center", "scale"))
# Transform the data using the estimated parameters
#train.transformed <- preproc.param %>% predict(data.train)
#test.transformed <- preproc.param %>% predict(data.test)


#test difference between centroids
lm.out<-lm(centered_variables ~ mydataLDA$spam)
summary(manova(lm.out),test=c("Wilks"))
cand.out<-candisc(lm.out)

#test for equality of covariance matrices
#Box's M test
x <- boxM(centered_variables, mydataLDA$spam)
print(x)

#create train and test set
set.seed(123) # so that results can be replicated afterwards
trainsize<-2500 # training set size 2500 and the remainder test set size = 2101
train = sample(nrow(mydataLDA), trainsize)
data.trainLDA<-mydataLDA[train,]
data.testLDA<-mydataLDA[-train,]

#linear discriminant analysis
lda.out<-lda(spam~.,data=data.trainLDA)
print(lda.out)
#pred.train<-predict(lda.out,books1)


#classify training sample under different scenarios

#classify accounting for different population sizes (priors) and equal classification costs
#specify the prior when conducting the analysis

lda.out<-lda(spam~.,prior=c(.6032,.3968),data=data.trainLDA)
pred.train<-predict(lda.out,prior=c(.6032,.3968),data.trainLDA)
pred.train$class[1:5]
pred.train$posterior[1:5,]
#observed versus predicted class labels
tab<-table(data.trainLDA$spam,pred.train$class)
print(tab)
#classification error
1-sum(diag(tab))/sum(tab)


#account for prior probabilities and asymmetric classification costs
classif<-ifelse(1*pred.train$posterior[,1]>=10*pred.train$posterior[,2],1,2)
tab<-table(data.trainLDA$spam,classif)
print(tab)
#classification error
1-sum(diag(tab))/sum(tab)


# CLASSIFY ON TEST SAMPLE using LDA model estimated on training sample
pred.test<-predict(lda.out,data.testLDA[,2:58])

#classification test sample after accounting for prior probabilities
tab<-table(data.testLDA$spam,pred.test$class)
print(tab)
1-sum(diag(tab))/sum(tab)

#ROC plot and AUC for classification of test sample with LDA
library(pROC)
par(cex=1.2)
roc(data.testLDA$spam, pred.test$posterior[,2],plot=TRUE)

#classification of test sample when accounting for asymmetric classification cost
classif2<-ifelse((pred.test$posterior[,1]*1)>=(pred.test$posterior[,2]*10),1,2)
tab<-table(data.testLDA$spam,classif2)
print(tab)
1-sum(diag(tab))/sum(tab)



# BAGGING & RANDOM FORESTS DATASET PREPARATION
library(randomForest)

# Recode dependent variable "spam" from the train and test sets used in classification trees (section 1)
# We recode factor levels with "spam" = 2, and "no_spam" = 1 

data.train$spam<-factor(ifelse(data.train$spam=="spam",2,1))
data.test$spam<-factor(ifelse(data.test$spam=="spam",2,1))


#############
#bagging
############

set.seed(2)
bag.mod=randomForest(spam~.,data=data.train,mtry=57,ntree=5000,prior=c(.6032,.3968),importance=TRUE)
bag.mod

#plot oob error
par(cex=1.2)
plot(1:3500,bag.mod$err.rate[1:3500,1],xlab="Number of iterations",ylab="OOB error",pch='',main="OOB error")
lines(1:3500,bag.mod$err.rate[1:3500,1],col="red")

#plot variable importance
importance(bag.mod,plot=TRUE)
varImpPlot(bag.mod,type=2,cex=1.2)

# train data DIFFERENT PRIORS & EQUAL MISSCLASSIFICATION COSTS
pred.train<-predict(bag.mod,newdata=data.train,type = "prob")
class.train<-ifelse(pred.train[,2]>=0.5,"spam","no_spam")
tab<-table(data.train$spam,class.train)
tab
#predicted error on
1-sum(diag(tab))/sum(tab)

# train data DIFFERENT PRIORS & ASSYMETRIC CLASSIFICATION COSTS
pred.train<-predict(bag.mod,newdata=data.train, type = "prob")
#predicted probability class 1 on train data
class.train<-ifelse(1*pred.train[,1]>=10*pred.train[,2],"no_spam","spam")
tab<-table(data.train$spam,class.train)
tab
1-sum(diag(tab))/sum(tab)

# test data DIFFERENT PRIORS & EQUAL MISSCLASSIFICATION COSTS
pred.test<-predict(bag.mod,newdata=data.test,type = "prob")
#err2(data.test$spam,pred.test)
class.test<-ifelse(pred.test[,2]>=0.5,"spam","no_spam")
tab<-table(data.test$spam,class.test)
tab
#predicted error on
1-sum(diag(tab))/sum(tab)

# test data DIFFERENT PRIORS & ASSYMETRIC CLASSIFICATION COSTS
pred.test<-predict(bag.mod,newdata=data.test, type = "prob")
class.test<-ifelse(1*pred.test[,1]>=10*pred.test[,2],"no_spam","spam")
tab<-table(data.test$spam,class.test)
tab
1-sum(diag(tab))/sum(tab)



#################
#random Forests
################
set.seed(2)
rf.mod=randomForest(as.factor(spam)~.,data=data.train,mtry=5,ntree=5000,prior=c(.6032,.3968),importance=TRUE)
rf.mod

# train data DIFFERENT PRIORS & EQUAL CLASSIFICATION COSTS
pred.train<-predict(rf.mod,newdata=data.train,type = "prob")
#err2(data.train$spam,pred.train)
class.train<-ifelse(pred.train[,2]>=0.5,"spam","no_spam")
tab<-table(data.train$spam,class.train)
tab
#predicted error on
1-sum(diag(tab))/sum(tab)

# train data DIFFERENT PRIORS & ASSYMETRIC CLASSIFICATION COSTS
pred.train<-predict(rf.mod,newdata=data.train, type = "prob")
class.train<-ifelse(1*pred.train[,1]>=10*pred.train[,2],"no_spam","spam")
tab<-table(data.train$spam,class.train)
tab
1-sum(diag(tab))/sum(tab)


# test data DIFFERENT PRIORS & EQUAL MISSCLASSIFICATION COSTS
pred.test<-predict(rf.mod,newdata=data.test,type = "prob")
class.test<-ifelse(pred.test[,2]>=0.5,"spam","no_spam")
tab<-table(data.test$spam,class.test)
tab
#predicted error on
1-sum(diag(tab))/sum(tab)

# test data DIFFERENT PRIORS & ASSYMETRIC CLASSIFICATION COSTS
pred.test<-predict(rf.mod,newdata=data.test, type = "prob")
class.test<-ifelse(1*pred.test[,1]>=10*pred.test[,2],"no_spam","spam")
tab<-table(data.test$spam,class.test)
tab
1-sum(diag(tab))/sum(tab)

#variable importance plot
#two measures are reported: 
#increase in MSE computed on OOB samples when removing variable
#decrease in node impurity (or increase in node purity) resulting from splits on the variable
importance(rf.mod)
varImpPlot(rf.mod)


#################
# Gradient Boosting
################
library(gbm)

# recode target variable from 1/2 binary so that it becomes 0/1 values
data.train$spam<-ifelse(data.train$spam==2,1,0)
data.test$spam<-ifelse(data.test$spam==2,1,0)

set.seed(2)
#use distribution="bernoulli" for binary target
#interaction.depth=4, means that we fit a tree that uses 4 splits 
#(and that includes at most a 4-th order interaction)
boost.mod=gbm(spam~.,data=data.train,distribution="bernoulli",n.trees=40000,interaction.depth=4,shrinkage=0.001,cv.folds=5)
gbm.perf(boost.mod,method="cv")
legend("topright",c("train error","CV error"),col=c("green","black"),lty=c(1,1))

#relative influence plot
par(cex=1.2)
summary(boost.mod,n.trees=21754)

#partial dependence plots
#plot(boost.mod,i="rm")
#plot(boost.mod,i="lstat")

#library(pdp)
#partial(boost.mod, pred.var = c("rm"), plot = TRUE, n.trees=19713)

# train data DIFFERENT PRIORS & EQUAL CLASSIFICATION COSTS
pred.train<-predict(boost.mod,n.trees=21754,newdata=data.train,type="response")
#err(data.train$spam,pred.train,cutoff=0.5)
class.train<-ifelse(pred.train>0.5,1,0)
tab<-table(data.train$spam,class.train)
tab
1-sum(diag(tab))/sum(tab)

# train data DIFFERENT PRIORS & ASSYMETRIC CLASSIFICATION COSTS
pred.train<-predict(boost.mod,newdata=data.train, type = "response")
class.train<-ifelse(pred.train<=1/11,0,1)
tab<-table(data.train$spam,class.train)
tab
1-sum(diag(tab))/sum(tab)


# test data DIFFERENT PRIORS & EQUAL CLASSIFICATION COSTS
pred.test<-predict(boost.mod,n.trees=21754,newdata=data.test,type="response")
#predicted probability class 1 on test data
class.test<-ifelse(pred.test>0.5,1,0)
tab<-table(data.test$spam,class.test)
tab
1-sum(diag(tab))/sum(tab)

# test data DIFFERENT PRIORS & ASSYMETRIC CLASSIFICATION COSTS
pred.test<-predict(boost.mod,newdata=data.test, type = "response")
#predicted probability class 1 on train data
class.test<-ifelse(pred.test<=1/11,0,1)
tab<-table(data.test$spam,class.test)
tab
1-sum(diag(tab))/sum(tab)

