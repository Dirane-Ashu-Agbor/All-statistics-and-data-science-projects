#Assignment 2 Task 4 Correspondence Analysis

rm(list = ls())
load("C:/Users/kebro/OneDrive/KU_Leuven/KUL Multiv/2020/datacar.Rdata")

library(gplots)
library(FactoMineR)
library(factoextra)
library(ca)

#data
dt=as.table(as.matrix(datacar))

#chi-squared test assumptions
row_count=rep(0,10)
col_count=rep(0,15)
total=sum(datacar)
for(i in 1:10){
  row_count[i]=sum(datacar[i,])
}
for(i in 1:15){
  col_count[i]=sum(datacar[,i])
}
eij=matrix(rep(0,150),nrow=10)
for(i in 1:10){
  for(j in 1:15){
    eij[i,j]=(row_count[i]*col_count[j])/total
  }
}
sum(eij>1)==150
(sum(eij<5)/150)<.2

min(eij)

#chi-squared test for dependence
chisq.test(datacar)

#CA summaries
#using two different CA functions
#results are consistent but the later allows for better plots
ca1=ca(datacar)
summary(ca1)

ca=CA(datacar, graph = FALSE,ncp = 2)
summary(ca)


#eigen values and biplots
eigens=get_eigenvalue(ca)
eigens
fviz_eig(ca)
fviz_ca_biplot(ca,repel=T)

#row statistics and plots
row=get_ca_row(ca)
row$coord
row$contrib
row$cos2
row$inertia
fviz_ca_row(ca)+xlim(-.6,.6)+ylim(-.3,.3)

#column statistics and plots
col=get_ca_col(ca)
col$coord
col$contrib
col$cos2
col$inertia
fviz_ca_col(ca)+ylim(-.2,.4)

#chi-squared test by hand
chi2=778.2049
df=(nrow(datacar)-1)*(ncol(datacar)-1)
pval=pchisq(chi2,df=df,lower.tail=F)
pval


#scree plot
fviz_screeplot(ca)