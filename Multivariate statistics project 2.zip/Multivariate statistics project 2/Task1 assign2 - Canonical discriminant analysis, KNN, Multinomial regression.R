load("C:/Users/oziel/Downloads/dwvs.Rdata")
#test difference between centroids
lm.out<-lm(cbind(F_rights,F_steal,F_crime,F_religion,F_realizeself
                 ,F_dogood,F_violence)~ as.factor(country),data=dwvs)
dim(dwvs)
#The p-value of the test is very low, so we can say that the groups
#have significantly different means
summary(lm.out)
summary(manova(lm.out),test=c("Wilks"))
boxM(dwvs[, 2:8], dwvs[, "country"])  #testng equality of cov matrices

#We perform a canonical discriminatn analysis and make use of the biplot 
#in canonical space. It can be seen that The Netherlands loads highly on 
#the F_rights factor, Nigeria on the F_realizesel factor and Philippines
#loads particularly highly on F_steal.
library(heplots)
library(candisc)
cand=candisc(lm.out, data=dwvs)
summary(cand)
plot(cand)
heplot(cand)

#raw coefficients
cand$coeffs.raw
#pooled within-group standardized
#canonical coefficients
cand$coeffs.std
#correlations between explanatory
#variables
# and canonical variates
cand$structure

#classify training observations using LDA

library(MASS)
lda.out<-lda(country~F_rights+F_steal+F_crime+F_religion+F_realizeself
             +F_dogood+F_violence,data=dwvs)
pred.train<-predict(lda.out,)
tab<-table(dwvs$country,pred.train$class)
tab
#hit rate
sum(diag(tab))/sum(tab) 

#classify test observations using LDA

pred.loocv<-lda(country~F_rights+F_steal+F_crime+F_religion+F_realizeself
                +F_dogood+F_violence,data=dwvs,  CV=TRUE)
tab<-table(dwvs$country,pred.loocv$class)
tab
#hit rate
sum(diag(tab))/sum(tab)
 
#classify training observations
 
 qda.out<-qda(country~F_rights+F_steal+F_crime+F_religion+F_realizeself
              +F_dogood+F_violence,data=dwvs)
 pred.train<-predict(qda.out,)
 tab<-table(dwvs$country,pred.train$class)
 tab
 #hit rate
 sum(diag(tab))/sum(tab)
 
 #classify test observations
 #assume equal prior probabilities classes
  pred.test<-qda(country~F_rights+F_steal+F_crime+F_religion+F_realizeself
                 +F_dogood+F_violence,data=dwvs, CV=TRUE)
 tab<-table(dwvs$country,pred.test$class)
 tab
 #hit rate
 sum(diag(tab))/sum(tab) 
 
 library(class)
 knnmax<-100
 err<-matrix(rep(0,knnmax),nrow=knnmax)
 for (j in 1:knnmax){
   predknn.train<- knn(dwvs[,2:8],dwvs[,2:8],dwvs$country, k=j)
   tab<-table(dwvs$country,predknn.train)
   tab
   #hit rate
   h=sum(diag(tab))/sum(tab)
   err[j,1]<-1- h}
plot(seq(1:100),err)

library(HDclassif)
hdda=hdda(dwvs[,2:8], cls=dwvs[,1], model="ALL")
summary(hdda)
pred.train<-predict(hdda,data=dwvs[,2:8])
tab<-table(dwvs$country,pred.train$class)
tab
#hit rate
sum(diag(tab))/sum(tab)
pred.test=hdda(dwvs[,2:8], cls=dwvs[,1], model="AKJBQKD", LOO=TRUE)
tab<-table(dwvs$country,pred.test$class)
tab
#hit rate
sum(diag(tab))/sum(tab) 

#MULTINOMIAL MODEL
##polytomous logit model
library(nnet)
m1<-multinom(country~F_rights+F_steal+F_crime+F_religion+F_realizeself
             +F_dogood+F_violence,data=dwvs,family=multinomial,
             maxit=1000,hess=TRUE)
summary(m1)
#compute hitrate training data
train.pred<-predict(m1,newdata=dwvs)
tab<-table(dwvs$country,train.pred)
tab
sum(diag(tab))/sum(tab)

#compute LOOCV
nobs<-3926
hit<-rep(0,nobs)
for (i in 1:nobs){
  train<-c(1:nobs)
  mod<-multinom(country~F_rights+F_steal+F_crime+F_religion+F_realizeself
                +F_dogood+F_violence,data=dwvs,subset=train[-i],print=FALSE,maxit=1000)
  pred<-predict(mod,newdata=dwvs[i,])
  hit[i]<-ifelse(pred==dwvs$country[i],1,0)}
 #hitrate
 mean(hit) 
 