#=======================#
# Cluster Analysis      #
#=======================#

rm(list = ls())

library(ggdendro)
require(graphics)
library(psych)
library(cluster)
library(effects) # effects plot
library(lattice)
library(HDclassif)
library(mclust)
library(clustvarsel)

setwd("H:/Masters_of_Statistics/Semester_3/Multivariate/Assignments/2")
load(file="shopping.Rdata")


#=========================#
#    Preparing the data   # 
#=========================#

## Remove records with missing data listwise
shopping.na<-na.omit(shopping)
## Standardizing Variables
zshopping<-scale(shopping.na,center=TRUE,scale=TRUE)
## compute Euclidean distances
distpref<-dist(zshopping, method = "euclidean",
                  diag = FALSE, upper = FALSE)


#==============================#
# Descriptive Statistics       #
#==============================#

summary(shopping)
cor(shopping)

par(mfrow = c(3,4))
boxplot(shopping$organising_trip, main = " Org. Trip", col="dark grey")
boxplot(shopping$knowing_buy, main = " Knowing what to buy", col="dark grey")
boxplot(shopping$duty_responsability, main = " Duty", col="dark grey")
boxplot(shopping$shopping_fun, main = " Fun", col="dark grey")
boxplot(shopping$take_at_ease, main = " Take at ease", col="dark grey")
boxplot(shopping$enjoy, main = " Enjoy", col="dark grey")
boxplot(shopping$shopping_drag, main = " What a Drag", col="dark grey")
boxplot(shopping$minimise_shoppingtime, main = " Minimum Time", col="dark grey")
boxplot(shopping$shopping_list, main = " List", col="dark grey")
boxplot(shopping$shopping_with_family, main = " Family", col="dark grey")
boxplot(shopping$have_stock, main = "Have Stock", col="dark grey")



#=======================================================================#
# 1.1) Hierarchical clustering with Ward's method on squared Euclidean  #
# distances followed by k-means with the centroid of the hierarchical   #
# clustering as starting point.                                         #
#=======================================================================#

##Ward's method on squared Euclidean distances

hiclust_ward<- hclust(distpref, "ward.D2")
par(pty="s")

par(mfrow=c(1,1))
plot(hiclust_ward,labels=hiclust_ward$labels,hang=-1,main="Ward's method")
ggdendrogram(hiclust_ward, rotate = TRUE, size = 1, theme_dendro = FALSE)

# classification of survey for solutions with 1-6 clusters
clustvar<-cutree(hiclust_ward, k=1:6)

# frequency distribution 5-cluster solution
table(clustvar[,1])
table(clustvar[,2])
table(clustvar[,3])
table(clustvar[,4])
table(clustvar[,5])
table(clustvar[,6])


# Ward's method effect plots with 4 clusters

nd <- data.frame(zshopping,cl=as.factor(clustvar[,3]))
names(nd)

plot(effect("cl",aov(organising_trip ~cl,data=nd)),main="Organize the shopping well",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(knowing_buy~cl,data=nd)),main="Knowing what to by",ylim=c(-2,2),cex=1.3,nrow = 2, ncol = 3,  more=TRUE)
plot(effect("cl",aov(duty_responsability~cl,data=nd)),main="Fulfill my duty",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(shopping_fun~cl,data=nd)),main="Shopping for Fun",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(take_at_ease~cl,data=nd)),main="Chopping at a leisurely pace",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(enjoy~cl,data=nd)),main="To Enjoy the atmosphere",ylim=c(-2,2),cex=1.3,nrow = 2, ncol = 3)
plot(effect("cl",aov(shopping_drag~cl,data=nd)),main="Shopping is a drag",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2,more=TRUE)
plot(effect("cl",aov(minimise_shoppingtime~cl,data=nd)),main="Minimum time",ylim=c(-2,2),cex=1.3,nrow = 2, ncol = 2,more=TRUE)
plot(effect("cl",aov(shopping_list~cl,data=nd)),main="Taking a list",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2,more=TRUE)
plot(effect("cl",aov(shopping_with_family~cl,data=nd)),main="Shopping with the whole family",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2)
plot(effect("cl",aov(have_stock~cl,data=nd)),main="Stock of products on hand",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2,more=TRUE)


#=================================================================#
# k-means with 2 clusters using centroid of Ward as starting point
nclust2<-2
stat2<-describeBy(zshopping,clustvar[,nclust2],mat=TRUE)
hcenter2<-matrix(stat2[,5],nrow=nclust2)
rownames(hcenter2)<-paste("c_",rep(1:nclust2),sep="")
colnames(hcenter2)<-c(colnames(zshopping))
kmean2<-kmeans(zshopping,centers=hcenter2,iter.max=200)

##number of observations per cluster
kmean2$size
## proportion of explained variance
kmean2$betweenss/kmean2$totss
#=================================================================#

#=================================================================#
# k-means with 3 clusters using centroid of Ward as starting point
nclust3<-3
stat3<-describeBy(zshopping,clustvar[,nclust3],mat=TRUE)
hcenter3<-matrix(stat3[,5],nrow=nclust3)
rownames(hcenter3)<-paste("c_",rep(1:nclust3),sep="")
colnames(hcenter3)<-c(colnames(zshopping))
kmean3<-kmeans(zshopping,centers=hcenter3,iter.max=200)

##number of observations per cluster
kmean3$size
## proportion of explained variance
kmean3$betweenss/kmean3$totss

#=================================================================#

#=================================================================#
# k-means with 4 clusters using centroid of Ward as starting point
nclust4<-4
stat4<-describeBy(zshopping,clustvar[,nclust4],mat=TRUE)
hcenter4<-matrix(stat4[,5],nrow=nclust4)
rownames(hcenter4)<-paste("c_",rep(1:nclust4),sep="")
colnames(hcenter4)<-c(colnames(zshopping))
kmean4<-kmeans(zshopping,centers=hcenter4,iter.max=200)

##number of observations per cluster
kmean4$size
## proportion of explained variance
kmean4$betweenss/kmean4$totss
#=================================================================#

#=================================================================#
# k-means with 5 clusters using centroid of Ward as starting point
nclust5<-5
stat5<-describeBy(zshopping,clustvar[,nclust5],mat=TRUE)
hcenter5<-matrix(stat5[,5],nrow=nclust5)
rownames(hcenter5)<-paste("c_",rep(1:nclust5),sep="")
colnames(hcenter5)<-c(colnames(zshopping))
kmean5<-kmeans(zshopping,centers=hcenter5,iter.max=200)

##number of observations per cluster
kmean5$size
## proportion of explained variance
kmean5$betweenss/kmean5$totss
#=================================================================#

#=================================================================#
# k-means with 6 clusters using centroid of Ward as starting point
nclust6<-6
stat6<-describeBy(zshopping,clustvar[,nclust6],mat=TRUE)
hcenter6<-matrix(stat6[,5],nrow=nclust6)
rownames(hcenter6)<-paste("c_",rep(1:nclust6),sep="")
colnames(hcenter6)<-c(colnames(zshopping))
kmean6<-kmeans(zshopping,centers=hcenter6,iter.max=200)

##number of observations per cluster
kmean6$size
## proportion of explained variance
kmean6$betweenss/kmean6$totss

kmean6$centers
#=================================================================#


#===============================================#
#   1.2) model-based clustering with hddc()     #
#===============================================#


## Analysis with HDclassif

#fit all models with K=1 to 6
#use BIC to select the number of dimensions
set.seed(1)
hddc.out<-hddc(zshopping,K=1:6,model="all",d_select="BIC")
hddc.out

plot(hddc.out)
table(hddc.out$class)

#========================================#
# model-based clustering using mclust()  #
#========================================#

mclust.out<-Mclust(zshopping)
summary(mclust.out)

dev.new(width=10, height=10, unit="in")
plot(mclust.out,what="BIC",ylim = c(-17000,-12700),legendArgs = list(x = "bottomleft"))

#===============================================#
# 2) Visualization with 2 Principal Components  #
#===============================================#
par(mfrow=c(1,1))

prcomp.out<-prcomp(zshopping)
summary(prcomp.out) # Based on Kaiser's rule 2 PC describe the data

#plot eigenvalues
plot(prcomp.out$sd^2,type="b", ylab = "Eigenvalues")
#compute variance accounted for by each component
round(prcomp.out$sd^2/sum(prcomp.out$sd^2),3)
comp<-as.matrix(zshopping)%*%prcomp.out$rotation

#=========================#
# Plots for Wards Method  #
#=========================#
par(mfrow=c(1,2))

## 2 Clusters

wards2 = clustvar[,2]

dev.new(width=10, height=10, unit="in")
plot(comp,main="Ward's with 2 clusters")
points(comp[wards2==1,],col="black",pch=19)
points(comp[wards2==2,],col="red",pch=19)
legend("bottomright",c("Like","Dislike"),col=c("black","red"),pch=c(19,19),bty="s")

## 3 Clusters
wards3 = clustvar[,3]
plot(comp,main="Ward's with 3 clusters")
points(comp[wards3==1,],col="black",pch=19)
points(comp[wards3==2,],col="red",pch=19)
points(comp[wards3==3,],col="green",pch=19)

# Ward's method effect plots with 2 and 3 clusters

# The model is run with 2 and then 3 clusters using the same code. 
nd <- data.frame(zshopping,cl=as.factor(clustvar[,3]))

#People who like to plan 
plot(effect("cl",aov(organising_trip ~cl,data=nd)),main="Organize the shopping well",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(knowing_buy~cl,data=nd)),main="Knowing what to by",ylim=c(-2,2),cex=1.3,nrow = 2, ncol = 3,  more=TRUE)
plot(effect("cl",aov(duty_responsability~cl,data=nd)),main="Fulfill my duty",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(shopping_list~cl,data=nd)),main="Taking a list",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2,more=TRUE)

#People who enjoy going shopping
plot(effect("cl",aov(shopping_fun~cl,data=nd)),main="Shopping for Fun",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(take_at_ease~cl,data=nd)),main="Chopping at a leisurely pace",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(enjoy~cl,data=nd)),main="To Enjoy the atmosphere",ylim=c(-2,2),cex=1.3,nrow = 2, ncol = 3)

#People who avoid going shopping
plot(effect("cl",aov(shopping_drag~cl,data=nd)),main="Shopping is a drag",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2,more=TRUE)
plot(effect("cl",aov(minimise_shoppingtime~cl,data=nd)),main="Minimum time",ylim=c(-2,2),cex=1.3,nrow = 2, ncol = 2,more=TRUE)

# Other common activities
plot(effect("cl",aov(shopping_with_family~cl,data=nd)),main="Shopping with the whole family",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2)
plot(effect("cl",aov(have_stock~cl,data=nd)),main="Stock of products on hand",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2,more=TRUE)


#===========================#
# Plots for K-means Method  #
#===========================#

par(mfrow=c(1,1))

## 4 Clusters
kmean4$cluster

dev.new(width=10, height=10, unit="in")
plot(comp,main="K-means clusters", xlim = c(-4.5,4.5))
points(comp[kmean4$cluster==1,],col="black",pch=19)
points(comp[kmean4$cluster==2,],col="red",pch=19)
points(comp[kmean4$cluster==3,],col="green",pch=19)
points(comp[kmean4$cluster==4,],col="blue",pch=19)
legend("bottomright",c("Like it","Hobby","planning","Dislike it"),col=c("black","red","green","blue"),pch=c(19,19,19,19),bty="s")



# K-means method effect plots with 4 clusters

nd <- data.frame(zshopping,cl=as.factor(kmean5$cluster))

#People who like to plan 
plot(effect("cl",aov(organising_trip ~cl,data=nd)),main="Organize the shopping well",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(knowing_buy~cl,data=nd)),main="Knowing what to by",ylim=c(-2,2),cex=1.3,nrow = 2, ncol = 3,  more=TRUE)
plot(effect("cl",aov(duty_responsability~cl,data=nd)),main="Fulfill my duty",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(shopping_list~cl,data=nd)),main="Taking a list",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2,more=TRUE)

#People who enjoy going shopping
plot(effect("cl",aov(shopping_fun~cl,data=nd)),main="Shopping for Fun",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(take_at_ease~cl,data=nd)),main="Chopping at a leisurely pace",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(enjoy~cl,data=nd)),main="To Enjoy the atmosphere",ylim=c(-2,2),cex=1.3,nrow = 2, ncol = 3)

#People who avoid going shopping
plot(effect("cl",aov(shopping_drag~cl,data=nd)),main="Shopping is a drag",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2,more=TRUE)
plot(effect("cl",aov(minimise_shoppingtime~cl,data=nd)),main="Minimum time",ylim=c(-2,2),cex=1.3,nrow = 2, ncol = 2,more=TRUE)

# Other common activities
plot(effect("cl",aov(shopping_with_family~cl,data=nd)),main="Shopping with the whole family",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2)
plot(effect("cl",aov(have_stock~cl,data=nd)),main="Stock of products on hand",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2,more=TRUE)


#===========================#
# Plots for hddc Method     #
#===========================#

#plot clusters extracted with HDDC in space of first two principal components

dev.new(width=10, height=10, unit="in")

plot(comp,main="HDCC clusters", xlim= c(-5,5))
points(comp[hddc.out$class==1,],col="black",pch=19)
points(comp[hddc.out$class==2,],col="red",pch=19)
points(comp[hddc.out$class==3,],col="green",pch=19)
points(comp[hddc.out$class==4,],col="blue",pch=19)
legend("bottomright",c("Hobby","Planning","Like it","Dislike it"),col=c("black","red","green","blue"),pch=c(19,19,19,19),bty="s")

# hdcc method effect plots with 4 clusters
nd <- data.frame(zshopping,cl=as.factor(hddc.out$class))

#People who like to plan 
plot(effect("cl",aov(organising_trip ~cl,data=nd)),main="Organize the shopping well",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(knowing_buy~cl,data=nd)),main="Knowing what to by",ylim=c(-2,2),cex=1.3,nrow = 2, ncol = 3,  more=TRUE)
plot(effect("cl",aov(duty_responsability~cl,data=nd)),main="Fulfill my duty",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(shopping_list~cl,data=nd)),main="Taking a list",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2,more=TRUE)

#People who enjoy going shopping
plot(effect("cl",aov(shopping_fun~cl,data=nd)),main="Shopping for Fun",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(take_at_ease~cl,data=nd)),main="Chopping at a leisurely pace",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(enjoy~cl,data=nd)),main="To Enjoy the atmosphere",ylim=c(-2,2),cex=1.3,nrow = 2, ncol = 3)

#People who avoid going shopping
plot(effect("cl",aov(shopping_drag~cl,data=nd)),main="Shopping is a drag",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2,more=TRUE)
plot(effect("cl",aov(minimise_shoppingtime~cl,data=nd)),main="Minimum time",ylim=c(-2,2),cex=1.3,nrow = 2, ncol = 2,more=TRUE)

# Other common activities
plot(effect("cl",aov(shopping_with_family~cl,data=nd)),main="Shopping with the whole family",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2)
plot(effect("cl",aov(have_stock~cl,data=nd)),main="Stock of products on hand",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2,more=TRUE)


#===========================#
# Plots for mclust Method   #
#===========================#
mclust<-mclust.out$classification
dev.new(width=10, height=10, unit="in")

plot(comp,main="mclust clusters", xlim = c(-4.5,4.5))
points(comp[mclust==1,],col="black",pch=19)
points(comp[mclust==2,],col="red",pch=19)
points(comp[mclust==3,],col="green",pch=19)
points(comp[mclust==4,],col="blue",pch=19)
legend("bottomright",c("Dislike it","Hobby","Like it","Planning"),col=c("black","red","green","blue"),pch=c(19,19,19,19),bty="s")



# mclust method with 4 clusters. 
nd <- data.frame(zshopping,cl=as.factor(mclust))

#People who like to plan 
plot(effect("cl",aov(organising_trip ~cl,data=nd)),main="Organize the shopping well",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(knowing_buy~cl,data=nd)),main="Knowing what to by",ylim=c(-2,2),cex=1.3,nrow = 2, ncol = 3,  more=TRUE)
plot(effect("cl",aov(duty_responsability~cl,data=nd)),main="Fulfill my duty",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(shopping_list~cl,data=nd)),main="Taking a list",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2,more=TRUE)

#People who enjoy going shopping
plot(effect("cl",aov(shopping_fun~cl,data=nd)),main="Shopping for Fun",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(take_at_ease~cl,data=nd)),main="Chopping at a leisurely pace",ylim=c(-2,2), cex=1.3,nrow = 2, ncol = 3, more=TRUE)
plot(effect("cl",aov(enjoy~cl,data=nd)),main="To Enjoy the atmosphere",ylim=c(-2,2),cex=1.3,nrow = 2, ncol = 3)

#People who avoid going shopping
plot(effect("cl",aov(shopping_drag~cl,data=nd)),main="Shopping is a drag",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2,more=TRUE)
plot(effect("cl",aov(minimise_shoppingtime~cl,data=nd)),main="Minimum time",ylim=c(-2,2),cex=1.3,nrow = 2, ncol = 2,more=TRUE)

# Other common activities
plot(effect("cl",aov(shopping_with_family~cl,data=nd)),main="Shopping with the whole family",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2)
plot(effect("cl",aov(have_stock~cl,data=nd)),main="Stock of products on hand",ylim=c(-2,2),cex=1.3, nrow = 2, ncol = 2,more=TRUE)


#===================================================#
# 3. Investigating the stability in selected model  #
#===================================================#

#split data
set.seed(89135)
sel<-sample(1:487,size=243,replace=FALSE)
train<-zshopping[sel,]
valid<-zshopping[-sel,]
nrow(train)

# cluster train data hiclus Ward + kmeans
disttrain<-dist(train, method = "euclidean", diag = FALSE, upper = FALSE)
wardtrain<- hclust(disttrain, "ward.D2")
nclust<-4
clustvar<-cutree(wardtrain, k=nclust)
stat<-describeBy(train,clustvar,mat=TRUE)
hcenter<-matrix(stat[,5],nrow=nclust)
rownames(hcenter)<-paste("c_",rep(1:nclust),sep="")
colnames(hcenter)<-c(colnames(train))
kmeantrain<-kmeans(train,centers=hcenter,iter.max=200)

# cluster validation data hiclus Ward + kmeans
distvalid<-dist(valid, method = "euclidean", diag = FALSE, upper = FALSE)
wardvalid<- hclust(distvalid, "ward.D2")
nclust<-4
clustvar<-cutree(wardvalid, k=nclust)
stat<-describeBy(valid,clustvar,mat=TRUE)
hcenter<-matrix(stat[,5],nrow=nclust)
rownames(hcenter)<-paste("c_",rep(1:nclust),sep="")
colnames(hcenter)<-c(colnames(valid))
kmeanvalid<-kmeans(valid,centers=hcenter,iter.max=200)

# function classify new points to nearest cluster centroid
clusters <- function(zshopping, centers) {
  # compute squared euclidean distance from each sample to each cluster center
  tmp <- sapply(seq_len(nrow(zshopping)),
                function(i) apply(centers, 1,
                                  function(v) sum((zshopping[i, ]-v)^2)))
  max.col(-t(tmp))  # find index of min distance
}


classif1<-clusters(valid, kmeantrain[["centers"]])
classif2<-kmeanvalid$cluster
table(classif1,classif2)

cl1<-as.factor(classif1)
cl2<-factor(classif2,levels=c("2","3","1","4"))
mat<-table(cl1,cl2)
print(mat)


#percentage of correct classification
sum(diag(mat))/sum(mat)
#Adjusted Rand Index
adjustedRandIndex(cl1,cl2)

