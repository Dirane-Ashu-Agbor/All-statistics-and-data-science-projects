rm(list=ls())
library(smacof)

load("C:/Users/kebro/OneDrive/KU_Leuven/KUL Multiv/2020/dirane/dissim.Rdata")
load("C:/Users/kebro/OneDrive/KU_Leuven/KUL Multiv/2020/dirane/confusion.Rdata")
print(dissim)

#ratio 
m1<-smacofSym(delta=dissim, ndim=2, type="ratio", init="torgerson")
#interval
m2<-smacofSym(delta=dissim, ndim=2, type="interval", init="torgerson")
#ordinal
m3<-smacofSym(delta=dissim, ndim=2, type="ordinal", init="torgerson")
#spline
m4<-smacofSym(delta=dissim, ndim=2 ,type="mspline",spline.degree =4 , spline.intKnots = 4, init="torgerson")

#stress-1 values
round(c(m1$stress,m2$stress,m3$stress,m4$stress),3)

par(mfrow=c(2,2))
plot(m3,plot.type="resplot",main="residual plot ordinal MDS")
plot(m3,plot.type="Shepard",main="Shepard diagram ordinal MDS")
plot(m4,plot.type="resplot",main="residual plot spline MDS")
plot(m4,plot.type="Shepard",main="Shepard diagram spline MDS")

#configuration ordinal MDS
par(mfrow=c(1,1))
plot(m3,plot.type="conf",main="configuration ordinal MDS")


#stress norm
set.seed(1)
rstress<-randomstress(n=36,ndim=2,nrep=500,type="ordinal")
#distribution of stress for random data
mean(rstress)-2*sd(rstress)

#permutation test
set.seed(1)
perm.car<-permtest(m3,nrep=500)
perm.car

#plot distribution stress
par(mfrow=c(1,2),pty="s")
hist(rstress,main="stress random data")
hist(perm.car$stressvec,main="stress permuted data")


#stability of solution using jackknife
jack.car<-jackmds(m3)
jack.car
plot(jack.car,xlim=c(-1.2,1.2),ylim=c(-1,1))

par(mfrow=c(1,1))

#construct external variable data set

external=as.data.frame(matrix(rep(0,36*3),ncol=3))
colnames(external)=c("length","count_short","count_long")

#the number of notes per alphanumeric symbol
external$length=c(2,4,4,3,1,4,3,4,2,4,3,4,2,
                  2,3,4,4,3,3,1,3,4,3,4,4,4,
                  5,5,5,5,5,5,5,5,5,5)

#the number of "short" notes per alphanumeric symbol
external$count_short=c(1,3,2,2,1,3,1,4,2,1,1,3,0,
                 1,0,2,1,2,3,0,2,3,1,2,1,2,
                 1,2,3,4,5,4,3,2,1,0)

#the number of "long" notes per alphanumeric symbol
external$count_long=external$length-external$count_short

#the proportion of "short" notes per alphanumeric symbol
external$prop_short=external$count_short/external$length

#the proportion of "long" notes per alphanumeric symbol
external$prop_long=external$count_long/external$length

#symbols that start with a short note
external$short_first=c(1,0,0,0,1,1,0,1,1,1,0,1,0,
                       0,0,1,0,1,1,0,1,1,1,0,0,0,
                       1,1,1,1,1,0,0,0,0,0)

#symbols that start with a long note
external$long_first=(external$short_first-1)*-1

#symbols that end with a short note
external$short_last=c(0,1,1,1,1,1,1,1,1,0,0,1,0,
                      1,0,1,0,1,1,0,0,0,0,0,0,1,
                      0,0,0,0,1,1,1,1,1,0)

#symbols that end with a long note
external$long_last=(external$short_last-1)*-1

fitmorse=mds(dissim,type = "ordinal")
bimorse=biplotmds(fitmorse,extvar = external)
plot(bimorse,mai="Biplot Vector Representation", vecscale = 0.8,
     xlim = c(-1.5, 1.5), vec.conf = list(col = "brown"), pch = 20, cex = 0.5)
