setwd('/Users/diran/Downloads/Advanced time series')
library(vars)
library(xtable)
library(readxl)
mydata<- read_excel("France_GDP_CPI.xls")
View(mydata)

#Try linear regression 1st #
# Linear regression ####
attach(mydata)
GDP_ts <- ts(GDP, frequency = 4,start = c(1975,1))
GDP_ts
length(GDP)
TREND<-1:176
ts.plot(TREND)
Q1<-c(rep(c(1,0,0,0),44))
Q2<-c(rep(c(0,1,0,0),44))
Q3<-c(rep(c(0,0,1,0),44))
Q4<-c(rep(c(0,0,0,1),44))
fit<-lm(GDP_ts~TREND+Q1+Q2+Q3+Q4)
summary(fit)
# as per the model, none of the quarterly GDP's are significantly better than the reference category  Q4!
# Linear regression residual plot
ts.plot(fit$residuals,main = "Residuals plot") #lack homoscedasticity, hence model is not valid!
# Time Series Analysis####
## Univariate analysis ####
# Declare data to be time series
GDP_ts <- ts(GDP, frequency = 4,start = c(1975,1))
#Plot of GDP
ts.plot(GDP_ts)

logGDP_ts<- log(GDP_ts)
par(mfrow =c(1,1))
ts.plot(log(GDP_ts),ylab="GDP", main="log transformed GDP") # Descriptive statistics
summary(logGDP_ts)
# Autocorrelation
acf(logGDP_ts)
#Augmented DF test to check stationarity
library(CADFtest)
max.lag<-round(sqrt(length(logGDP_ts)));max.lag #13
CADFtest(GDP_ts, type= "trend", criterion= "BIC", max.lag.y=max.lag) # p=0.2 ADF test on original series 
CADFtest(logGDP_ts, type= "trend", criterion= "BIC", max.lag.y=max.lag) # ADF test on log tranformed GDP
#p 0.84 fail to reject H0, hence non stationary

# GDP in differences
dlogGDP_ts<-diff((logGDP_ts)); dlogGDP_ts
par(mfrow =c(1,2))
ts.plot(dlogGDP_ts,ylab="Change in GDP", main="Change in GDP")
monthplot(dlogGDP_ts,ylab="Change in GDP", main="Quarterly change in GDP") #not much seasonality

#Augmented DF test
library(CADFtest)
max.lag<-round(sqrt(length(dlogGDP_ts))) #13
CADFtest(dlogGDP_ts, type= "trend", criterion= "BIC", max.lag.y=max.lag) # p=4.698e-05 ADF test on first difference log GDP
dslogGDP_ts<- diff(diff((logGDP_ts)))
CADFtest(dslogGDP_ts, type= "trend", criterion= "BIC", max.lag.y=max.lag) # p=2.2e-16 ADF test on second diff log GDP
#The p-values -> 0:00 < 5%. We reject H0
#and conclude that the time series is stationary.
# Hence, time series are integrated of order one.

## Key correlograms ####
par(mfrow=c(1,2))
acf(dlogGDP_ts,main= "ACF of stationary series") #there are some significant correlations until lag1
pacf(dlogGDP_ts,main= "PACF of stationary series") #there are some significant correlations
Box.test(dlogGDP_ts, lag = max.lag, type = "Ljung-Box") # p<0.05 hence series is not white noise
#There are many significant correlations and partial correlations. The time series is not white noise.


#ARIMA(1,1,1)#
fit_arma11<-arima(logGDP_ts,order=c(1,1,1))
fit_arma11 #aic -1409.72
AIC(fit_arma11,k=log(176)) #bic -1400.208
Box.test(fit_arma11$residuals,lag=max.lag,type="Ljung-Box") # p=0.33 white noise, valid model!
par(mfrow=c(1,2))
plot(fit_arma11$residuals) 
acf(fit_arma11$residuals) # one borderline significant correlations
pacf(fit_arma11$residuals) # one borderline significant correlations and very weak seasonal effects
acf(fit_arma11$residuals^2)

#ARIMA(1,1,2)#
fit_arma12<-arima(logGDP_ts,order=c(1,1,2))
fit_arma12 #aic -1408.38 
Box.test(fit_arma12$residuals,lag=max.lag,type="Ljung-Box") # p=0.38 white noise valid model
AIC(fit_arma12,k=log(176)) #bic  -1395.7
par(mfrow=c(1,1))
plot(fit_arma12$residuals) 
acf(fit_arma12$residuals) # no significant autocorrelation
pacf(fit_arma12$residuals) # no significant correlations but no seasonal effects
acf(fit_arma12$residuals^2)

#ARIMA(1,1,3)
fit_arma13<-arima(logGDP_ts,order=c(1,1,3))
fit_arma13 #aic -1411.45
AIC(fit_arma13,k=log(176)) #bic -1395.594
Box.test(fit_arma13$residuals,lag=max.lag,type="Ljung-Box") # p=0.04 Not white noise, NOT VALID MODEL
par(mfrow=c(1,1))
plot(fit_arma13$residuals) 
acf(fit_arma13$residuals) # one very significant autocorrelation
pacf(fit_arma13$residuals) # one very significant autocorrelation and one on the border
acf(fit_arma13$residuals^2) #significant correlations

#ARIMA(2,1,1)#
fit_arma21<-arima(logGDP_ts,order=c(2,1,1))
fit_arma21 #aic -1408.75
AIC(fit_arma21,k=log(176)) #bic -1396.064
Box.test(fit_arma21$residuals,lag=max.lag,type="Ljung-Box") # p=0.35 White noise, Valid model!
par(mfrow=c(1,1))
plot(fit_arma21$residuals) 
acf(fit_arma21$residuals) # no significant correlations
pacf(fit_arma21$residuals) # no significant correlations and but very weak seasonal effect
acf(fit_arma21$residuals^2)

#ARIMA(2,1,2) #
fit_arma22<-arima(logGDP_ts,order=c(2,1,2))
fit_arma22 #aic -1415.12 
Box.test(fit_arma22$residuals,lag=max.lag,type="Ljung-Box") #white noise p=0.45
AIC(fit_arma22,k=log(176)) #bic -1399.272 
par(mfrow=c(1,3))
plot(fit_arma22$residuals) 
acf(fit_arma22$residuals) # one significant autocorrelation
pacf(fit_arma22$residuals) # no significant correlations and no seasonality
acf(fit_arma22$residuals^2)



####--------FORECAST WITH BOTH ARIMA(1,1,1) AND ARIMA (2,1,2) MODELS

#forecast arima(1,1,1)
forecast_model<-predict(fit_arma11,n.ahead=20) # prediction for 5 years
expected<-forecast_model$pred
par(mfrow=c(1,1))
expected
forecast_model
lower<-forecast_model$pred-qnorm(0.975)*forecast_model$se
upper<-forecast_model$pred+qnorm(0.975)*forecast_model$se
predictions<- cbind(exp(lower),exp(expected),exp(upper));predictions
plot.ts(GDP_ts,xlim=c(1974,2023),ylim=c(200000,600000),main="ARIMA(1,1,1) forecast")
lines(exp(expected),col="green")
lines(exp(lower),col="red")
lines(exp(upper),col="red")
legend(2010,300000, legend=c("Expected value", "Prediction interval"),
       col=c("green","red"),lty=c(1,1,1),cex=0.8)

#forecast arima(2,2)
forecast_model2<-predict(fit_arma22,n.ahead=20) # prediction for 5 years
expected<-forecast_model2$pred
par(mfrow=c(1,1))
expected
forecast_model2
lower<-forecast_model2$pred-qnorm(0.975)*forecast_model2$se
upper<-forecast_model2$pred+qnorm(0.975)*forecast_model2$se
predictions<- cbind(exp(lower),exp(expected),exp(upper));predictions
plot.ts(GDP_ts,xlim=c(1974,2023),ylim=c(200000,600000),main="ARIMA(2,1,2) forecast")
lines(exp(expected),col="green")
lines(exp(lower),col="red")
lines(exp(upper),col="red")
legend(2010,300000, legend=c("Expected value", "Prediction interval"),
       col=c("green","red"),lty=c(1,1,1),cex=0.8)


#forecast validation of BIC model arma(1,1)

S=round(0.70*length(logGDP_ts))
h=1
error1.h<-c()
for (i in S:(length(logGDP_ts)-1))
{
  mymodel.sub<-arima(logGDP_ts[1:i], order = c(1,1,1),method="ML")
  predict.h<-predict(mymodel.sub,n.ahead=h)$pred[h]
  error1.h<-c(error1.h,logGDP_ts[i+h]-predict.h)
}
error1.h
MAE<-mean(abs(error1.h))
MAE
RMSE <- sqrt(mean((error1.h)^2))
RMSE

# forecast validation AIC model arma(2,2)

S=round(0.70*length(logGDP_ts))
h=1
error2.h<-c()
for (i in S:(length(logGDP_ts)-1))
{
  mymodel.sub<-arima(logGDP_ts[1:i], order = c(2,1,2),method="ML")
  predict.h<-predict(mymodel.sub,n.ahead=h)$pred[h]
  error2.h<-c(error2.h,logGDP_ts[i+h]-predict.h)
}
error2.h
MAE<-mean(abs(error2.h))
MAE
RMSE <- sqrt(mean((error2.h)^2))
RMSE

# Test if forecast performance of the two models using absolute value loss is significantly different or not
library(forecast)
# perform a Diebold-Mariano Test 
dm.test(error1.h,error2.h,h=h,power=1)  # for abs value loss use power=1 (for sq value loss set power=2)


####################### MULTIVARIATE ANALYSIS #########################################################

CPI_ts <- ts(CPI, frequency = 4,start = c(1975,1))
CPI_ts
#Plot
par(mfrow=c(1,1))
ts.plot(CPI_ts)
# log of CPi
logCPI_ts<- log(CPI_ts)
# CPI in differences
dlogCPI_ts<-diff((logCPI_ts)); dlogCPI_ts
par(mfrow =c(1,2))
ts.plot(dlogCPI_ts,ylab="Change in CPI", main="Change in CPI")
monthplot(dlogCPI_ts,ylab="Change in CPI", main="Quarterly change in CPI") # slight seasonality in quarter 2 


#Augmented DF test
library(CADFtest)
max.lag<-round(sqrt(length(dlogCPI_ts)))#13
max.lag
CADFtest(dlogCPI_ts, type= "drift", criterion= "BIC", max.lag.y=max.lag) 
# p= 0.26 fail to reject H0 hence series non stationary
par(mfrow=c(1,2))
acf(dlogCPI_ts,main= "ACF of stationary series") #there are many significant correlations
pacf(dlogCPI_ts,main= "PACF of stationary series") #there are many significant correlations
Box.test(dlogCPI_ts, lag = max.lag, type = "Ljung-Box") # p<0.05 not white noise
#There are many significant correlations and partial correlations. The time series is not white noise.


### Seasonal log difference difference
dslogCPI_ts<- diff(diff(logCPI_ts))

CADFtest(dslogCPI_ts, type= "drift", criterion= "BIC", max.lag.y=max.lag) # Stationary
# p=0.006 rejects HO, hence Stationary
par(mfrow=c(1,3))
ts.plot(dslogCPI_ts,col=c("black","red"), lty=1:2, main="seasonal log differences CPI")
acf(dslogCPI_ts,main= "ACF of stationary series") #there are some significant correlations
pacf(dslogCPI_ts,main= "PACF of stationary series") #there are some significant correlations

Box.test(dslogCPI_ts, lag = max.lag, type = "Ljung-Box") # p<0.05 not white noise
#There are many significant correlations and partial correlations. The time series is not white noise.


#------------A little diversion from our Multivariate analysis

# BASED ON THE ACF AND PACF PLOTS, THE CPI SERIES IS NOT WHITE NOISE AND THERE IS SEASONALITY
# IF WE WERE TO PROPOSE A UNIVARIATE MODEL THAT TAKES INTO ACCOUNT SEASONALITY WE PROPOSED 
# THESE THREE SARIMA MODELS

#sarima(2,2)(0,1)
fit_sarma22<-arima(dslogCPI_ts,order=c(2,1,2),seasonal = list(order = c(0, 1, 1))) 
fit_sarma22 #aic --1385.3
AIC(fit_sarma22,k=log(176)) #BIC= -1366.27 further decreased!
Box.test(fit_sarma22$residuals,lag=max.lag,type="Ljung-Box") # p= 0.16 White noise, Valid model
par(mfrow=c(1,3))
plot(fit_sarma22$residuals) 
acf(fit_sarma22$residuals) # few borderline autocorrelations!
pacf(fit_sarma22$residuals) # a couple significant autocorrelations and seasonality improved!

#sarima(2,3)(0,1) 
fit_sarma23<-arima(dslogCPI_ts,order=c(2,1,3),seasonal = list(order = c(0, 1, 1)))
fit_sarma23 #aic -1383.23
AIC(fit_sarma23,k=log(176)) #BIC= -1361.03
Box.test(fit_sarma23$residuals,lag=max.lag,type="Ljung-Box") # white noise p=0.15, valid model!
par(mfrow=c(1,3))
plot(fit_sarma23$residuals) #homoscedasticity
acf(fit_sarma23$residuals) #no significant autocorrelations!
pacf(fit_sarma23$residuals) # no significant autocorrelations

#sarima(3,3)(0,2)
fit_sarma33<-arima(dslogCPI_ts,order=c(3,1,3),seasonal = list(order = c(0, 1, 2))) #middle zero for seasonality
fit_sarma33 #aic -1380.56
AIC(fit_sarma33,k=log(176)) #BIC= -1352.02 further decreased!
Box.test(fit_sarma33$residuals,lag=max.lag,type="Ljung-Box") # white noise p= 0.22, valid model!
par(mfrow=c(1,3))
plot(fit_sarma33$residuals)
acf(fit_sarma33$residuals) #no autocorrelations!
pacf(fit_sarma33$residuals) # no autocorrelations


###  GARCH MODEL (Not included on the slides)
#based on the PACF of the seasonal log difference of CPI (below) we can see atleast 3 significant partial autocorrrelations so we try AR(3)
par(mfrow=c(2,1))
acf(dslogCPI_ts,main= "ACF of stationary series") #there are some significant correlations
pacf(dslogCPI_ts,main= "PACF of stationary series") #significant correlations atleast #AR(3) atmost #AR(5)

fit_ar<-arima(dslogCPI_ts,order=c(5,0,0)) # I tried AR(1) to AR(4) but none were validated except AR(5)
fit_ar
plot(fit_ar$residuals)
acf(fit_ar$residuals)
Box.test(fit_ar$residuals,lag=max.lag,type="Ljung-Box") # pvalue=0.051 white noise valid model
par(mfrow=c(1,1))
acf(fit_ar$residuals^2) # No overly significant autocorrelations thus homoscedasticity.

# Not enough evidence of heteroscedasticity so we stop here and do not model GARCH

## 
##library(fGarch)
#fit_garch<-garchFit(~arma(5,0)+garch(5,5),data=dslogCPI_ts)
#summary(fit_garch)
#plot(fit_garch)
##
#fit_garch2<-garchFit(~arma(5,0)+garch(1,1),cond.dist="QMLE",data=dslogCPI_ts)
#summary(fit_garch2)
#plot(fit_garch2)
#summary(fit_garch2)
#plot(fit_garch2)



#----------- Lets come back to our Multivariate analysis

####LINEAR REGRESSION#####
linear <- lm(dslogGDP_ts ~ dslogCPI_ts)
summary(linear)
par(mfrow=c(1,2))
plot.ts(linear$residuals, ylab="Residuals", main="Residuals of the linear regression")
acf(linear$residuals, main="ACF of the residuals of the linear regression") # one significant autocorrelation until lag 1
par(mfrow=c(1,1))
pacf(linear$residuals, main="PACF of the residuals of the linear regression") # we see few significant correlations and few borderline, we try ADLM
######A few significant lags#####
Box.test(linear$residuals, lag = 13, type = "Ljung-Box") ### not white noise so NOT VALIDATED###


### DLM ###
# DLM(1)
lag <- 1
n <- length(dslogGDP_ts)
dslogGDP.0 <- dslogGDP_ts[(lag+1):n]
dslogCPI.0 <- dslogCPI_ts[(lag+1):n]
dslogCPI.1 <- dslogCPI_ts[lag:(n-1)]
fit_dlm1 <- lm(dslogGDP.0 ~ dslogCPI.0+dslogCPI.1)
summary(fit_dlm1)
plot.ts(fit_dlm1$residuals)
acf(fit_dlm1$residuals) # one significant autocorrelation
Box.test(fit_dlm1$residuals, lag = max.lag, type = "Ljung-Box") # p=8.329e-06 not white noise not valid model!


# DLM(2)
lag <- 2
n <- length(dslogGDP_ts)
dslogGDP.0 <- dslogGDP_ts[(lag+1):n]
dslogCPI.0 <- dslogCPI_ts[(lag+1):n]
dslogCPI.1 <- dslogCPI_ts[lag:(n-1)]
dslogCPI.2<-dslogCPI_ts[(lag-1):(n-2)]
fit_dlm2 <- lm(dslogGDP.0 ~ dslogCPI.0+dslogCPI.1+dslogCPI.2)
summary(fit_dlm2)
plot.ts(fit_dlm2$residuals)
acf(fit_dlm2$residuals) # one significant autocorrelation
Box.test(fit_dlm2$residuals, lag = max.lag, type = "Ljung-Box") # not white noise not valid model!


### ADLM ###
# ADLM(1)
lag <- 1
n <- length(dslogGDP_ts)
dslogGDP.0 <- dslogGDP_ts[(lag+1):n]
dslogCPI.0 <- dslogCPI_ts[(lag+1):n]
dslogCPI.1 <- dslogCPI_ts[lag:(n-1)]
dslogGDP.1<-dslogGDP_ts[lag:(n-1)]
fit_adlm1 <- lm(dslogGDP.0 ~ dslogGDP.1+dslogCPI.0+dslogCPI.1)
plot.ts(fit_adlm1$residuals)
acf(fit_adlm1$residuals) # no significant autocorrelation
Box.test(fit_adlm1$residuals, lag = max.lag, type = "Ljung-Box") # pvalue 0.08 WHITE NOISE valid model!
summary(fit_adlm1)

# ADLM(2)
lag <- 2
n <- length(dslogGDP_ts)
dslogGDP.0 <- dslogGDP_ts[(lag+1):n]
dslogCPI.0 <- dslogCPI_ts[(lag+1):n]
dslogCPI.1 <- dslogCPI_ts[lag:(n-1)]
dslogGDP.1<-dslogGDP_ts[lag:(n-1)]
dslogCPI.2<-dslogCPI_ts[(lag-1):(n-2)]
dslogGDP.2<-dslogGDP_ts[(lag-1):(n-2)]
fit_adlm2 <- lm(dslogGDP.0 ~ dslogGDP.1+dslogGDP.2+dslogCPI.0+dslogCPI.1+dslogCPI.2)
plot.ts(fit_adlm2$residuals)
acf(fit_adlm2$residuals)
Box.test(fit_adlm2$residuals, lag = max.lag, type = "Ljung-Box") # pvalue 0.06 valid model
summary(fit_adlm2)

#### Both ADLM(1) and ADLM(2) are validated because there are no significant correlation of residuals and residuals are white noise.
# Also lag 1 gdp is significant

###### GRANGER CAUSALITY #######
# CPI may not be granger casual
# lets check- Granger Causality test ####
fit_adlm_nox <- lm(dslogGDP.0 ~ dslogGDP.1)
anova(fit_adlm2,fit_adlm_nox) # p=0.86 fail to reject the null of no causality


######COINTEGRATION USING ENGLEGRANGER######
cointegration <- lm(logCPI_ts ~ logGDP_ts)
summary(cointegration)
cointegration_res <- cointegration$res
plot.ts(cointegration_res)
#if our residuals are stationary, these TS are cointegrated
CADFtest(cointegration_res, type="drift", criterion="BIC", max.lag.y=13)
#we got p-value of 0.177 #Cannot reject H0,hence not stationary, thus no cointegration
cointegration2 <- lm(logGDP_ts ~ logCPI_ts)
summary(cointegration2)
cointegration2_res <- cointegration2$res
plot.ts(cointegration2_res)
CADFtest(cointegration2_res, type="drift", criterion="BIC", max.lag.y=13)
#we got p-value of 0.611 # We cannot reject H0 of non-stationarity, hence no evidence of cointegration
#######

##Cointegration-Johansen test##
logdata<-data.frame(log(GDP), log(CPI))
names(logdata)<-c("logGDP","logCPI")
#attach(logdata)#
library(vars)
VARselect(logdata,lag.max=13,type="const",season = 4)
# SC criterion lag length =2
library(urca)
trace_test<-ca.jo(logdata,type="trace",K=2,ecdet="const",spec="transitory",season = 4)
summary(trace_test)
#Reject H0: r = 0 at all levels
#Cannot reject H0: r<=1 at all levels
#For r=0, the test statistics is larger than then the critical value (56.84 > 19:96), 
#thus there is at least one cointegrating relation. 
#For r=1, the test statistics is smaller than then the critical value (8.95 < 9:24). 
#Hence, log(GDP) and log(CPI) are cointegrated
maxeigen_test<-ca.jo(logdata,type="eigen",K=2,ecdet="const",spec="transitory", season=4)
summary(maxeigen_test)


####VECM Model#######
fit_vecm<-cajorls(trace_test,r=1)
fit_vecm
fit_var<-vec2var(trace_test,r=1)
myforecast<-predict(fit_var,n.ahead=16)
myforecast
par(mfrow =c(1,1))
#plotting forecast for logGDP
logGDP_forecast<-ts(myforecast$fcst$logGDP[,1],frequency=4,start=c(2018,4))
logGDP_lower<-ts(myforecast$fcst$logGDP[,2],frequency=4,start=c(2018,4))
logGDP_upper<-ts(myforecast$fcst$logGDP[,3],frequency=4,start=c(2018,4))
ts.plot(logGDP_ts,logGDP_forecast,logGDP_lower,logGDP_upper,col=c("black","green","red","red"),
        xlim=c(1974,2020),ylab='logGDP', main='Forecast of logGDP VECM(1) model')
#plotting forecast for logCPI
logCPI_forecast<-ts(myforecast$fcst$logCPI[,1],frequency=4,start=c(2018,4))
logCPI_lower<-ts(myforecast$fcst$logCPI[,2],frequency=4,start=c(2018,4))
logCPI_upper<-ts(myforecast$fcst$logCPI[,3],frequency=4,start=c(2018,4))
ts.plot(logCPI_ts,logCPI_forecast,logCPI_lower,logCPI_upper,col=c("black","green","red","red"),
        xlim=c(1974,2020), ylab='logCPI', main='Forecast of logCPI VECM(1) model')

